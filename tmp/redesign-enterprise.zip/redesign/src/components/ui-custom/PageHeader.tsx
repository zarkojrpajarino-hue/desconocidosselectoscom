import { ReactNode } from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Plus, Download, Settings } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface PageHeaderProps {
  title: string;
  description?: string;
  badge?: {
    label: string;
    variant?: 'default' | 'secondary' | 'outline' | 'destructive';
  };
  backButton?: boolean;
  children?: ReactNode;
  actions?: ReactNode;
  className?: string;
}

export function PageHeader({
  title,
  description,
  badge,
  backButton,
  children,
  actions,
  className,
}: PageHeaderProps) {
  const navigate = useNavigate();

  return (
    <div className={cn('mb-8', className)}>
      <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        {/* Left side: Back button + Title */}
        <div className="flex items-start gap-4">
          {backButton && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(-1)}
              className="mt-0.5 -ml-2"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
          )}
          <div className="space-y-1">
            <div className="flex items-center gap-3">
              <h1 className="text-h2 text-foreground">{title}</h1>
              {badge && (
                <Badge variant={badge.variant || 'secondary'}>
                  {badge.label}
                </Badge>
              )}
            </div>
            {description && (
              <p className="text-body text-muted-foreground max-w-2xl">
                {description}
              </p>
            )}
          </div>
        </div>

        {/* Right side: Actions */}
        {actions && (
          <div className="flex items-center gap-2 flex-shrink-0">
            {actions}
          </div>
        )}
      </div>

      {/* Children (tabs, filters, etc.) */}
      {children && <div className="mt-6">{children}</div>}
    </div>
  );
}

// Action buttons presets
interface ActionButtonProps {
  onClick?: () => void;
  label?: string;
  icon?: ReactNode;
  variant?: 'default' | 'outline' | 'secondary' | 'ghost';
}

export function CreateButton({ onClick, label = 'Crear nuevo' }: ActionButtonProps) {
  return (
    <Button onClick={onClick} className="gap-2">
      <Plus className="h-4 w-4" />
      {label}
    </Button>
  );
}

export function ExportButton({ onClick, label = 'Exportar' }: ActionButtonProps) {
  return (
    <Button onClick={onClick} variant="outline" className="gap-2">
      <Download className="h-4 w-4" />
      {label}
    </Button>
  );
}

export function SettingsButton({ onClick }: ActionButtonProps) {
  return (
    <Button onClick={onClick} variant="ghost" size="icon">
      <Settings className="h-5 w-5" />
    </Button>
  );
}

export default PageHeader;
