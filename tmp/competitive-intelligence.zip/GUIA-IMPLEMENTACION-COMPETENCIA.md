# 🎯 GUÍA COMPLETA: ANÁLISIS COMPETITIVO EN IA

## 📊 RESUMEN EJECUTIVO

Has pedido añadir **Análisis de Competidores** dentro del Análisis con IA, con límites por plan.

**Lo que he creado:**
✅ SQL para tabla de competidores
✅ Edge Function actualizada con análisis competitivo
✅ Componente AIAnalysis actualizado
✅ Límites por plan configurados
✅ Todo listo para implementar

---

## 🎯 LÍMITES POR PLAN

| Plan | Análisis/Mes | Análisis Competencia | Max Competidores | Profundidad |
|------|--------------|---------------------|------------------|-------------|
| **Free** | 1 | ❌ No | 0 | Básica |
| **Trial** | 2 | ✅ Sí | 1 | Estándar |
| **Starter** | 4 | ✅ Sí | 3 | Estándar |
| **Professional** | 8 | ✅ Sí | 10 | Avanzada |
| **Enterprise** | ∞ | ✅ Sí | ∞ | Premium |

---

## 📦 ARCHIVOS CREADOS (4)

### 1. **competitors-table.sql** (8 KB)
- Tabla `competitors` completa
- Tabla `competitor_analyses` (histórico)
- Funciones auxiliares
- RLS policies
- Índices optimizados

### 2. **analyze-project-data-v3-edge-function.ts** (22 KB)
- Edge Function actualizada
- Incluye análisis competitivo
- Límites por plan
- Prompt profesional para IA

### 3. **AIAnalysis-Updated.tsx** (18 KB)
- Componente React actualizado
- Nueva tab "Competencia"
- Visualización completa
- ExportButton incluido

### 4. **GUIA-IMPLEMENTACION-COMPETENCIA.md** (Este archivo)
- Guía paso a paso
- Ejemplos de código
- Checklist de testing

---

## 🚀 PASO 1: EJECUTAR SQL (5 min)

### 1.1 Abrir Supabase SQL Editor
```
https://supabase.com/dashboard/project/[TU_PROJECT]/sql
```

### 1.2 Copiar y Ejecutar
Copiar TODO el contenido de `competitors-table.sql` y ejecutar.

### 1.3 Verificar Tablas Creadas
```sql
-- Verificar tabla competitors
SELECT * FROM competitors LIMIT 1;

-- Verificar tabla competitor_analyses
SELECT * FROM competitor_analyses LIMIT 1;

-- Verificar función
SELECT can_add_competitor('[TU_ORG_ID]');
```

✅ **Resultado esperado:** Tablas creadas, sin errores.

---

## 🚀 PASO 2: ACTUALIZAR TABLA AI_ANALYSIS_RESULTS (2 min)

Añadir columna para análisis competitivo:

```sql
-- Añadir columna competitive_analysis
ALTER TABLE ai_analysis_results
ADD COLUMN IF NOT EXISTS competitive_analysis JSONB;

-- Añadir índice
CREATE INDEX IF NOT EXISTS idx_ai_analysis_competitive 
ON ai_analysis_results USING GIN (competitive_analysis);
```

---

## 🚀 PASO 3: DESPLEGAR NUEVA EDGE FUNCTION (10 min)

### 3.1 Crear Carpeta
```bash
mkdir supabase/functions/analyze-project-data-v3
```

### 3.2 Copiar Archivo
Copiar `analyze-project-data-v3-edge-function.ts` a:
```
supabase/functions/analyze-project-data-v3/index.ts
```

### 3.3 Configurar Variables de Entorno
```bash
# Asegurarse de tener LOVABLE_API_KEY configurada
supabase secrets set LOVABLE_API_KEY=tu_api_key_aqui
```

### 3.4 Desplegar
```bash
supabase functions deploy analyze-project-data-v3
```

### 3.5 Verificar Deployment
```bash
supabase functions list
```

✅ **Resultado esperado:** Función desplegada y activa.

---

## 🚀 PASO 4: ACTUALIZAR COMPONENTE AIAnalysis (5 min)

### 4.1 Backup del Componente Actual
```bash
# Hacer backup por si acaso
cp src/pages/AIAnalysis.tsx src/pages/AIAnalysis.backup.tsx
```

### 4.2 Reemplazar Componente
Copiar `AIAnalysis-Updated.tsx` a:
```
src/pages/AIAnalysis.tsx
```

### 4.3 Verificar Imports
Asegurarse que estos imports existan:
```tsx
import { ExportButton } from '@/components/ExportButton';
import { useCurrentOrganization } from '@/hooks/useCurrentOrganization';
```

---

## 🚀 PASO 5: ACTUALIZAR LLAMADA EN FRONTEND (2 min)

Si tu componente actual usa `analyze-project-data` o `analyze-project-data-v2`, actualizar a `v3`:

**ANTES:**
```tsx
const response = await fetch(
  `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-project-data`,
  // ...
);
```

**DESPUÉS:**
```tsx
const response = await fetch(
  `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-project-data-v3`,
  // ...
);
```

---

## 🚀 PASO 6: AÑADIR COMPETIDORES DE PRUEBA (3 min)

Para testing, añadir algunos competidores:

```sql
-- Reemplazar [TU_ORG_ID] con tu organization_id real
INSERT INTO competitors (organization_id, name, website, industry, pricing_model, min_price, max_price, features, company_size)
VALUES 
  (
    '[TU_ORG_ID]',
    'Competitor A',
    'https://competitora.com',
    'SaaS',
    'subscription',
    99.00,
    299.00,
    '["CRM", "Analytics", "Reporting", "API Access"]'::jsonb,
    'medium'
  ),
  (
    '[TU_ORG_ID]',
    'Competitor B',
    'https://competitorb.com',
    'SaaS',
    'freemium',
    0.00,
    199.00,
    '["CRM", "Email Marketing", "Lead Scoring"]'::jsonb,
    'small'
  ),
  (
    '[TU_ORG_ID]',
    'Competitor C',
    'https://competitorc.com',
    'SaaS',
    'subscription',
    199.00,
    499.00,
    '["CRM", "Analytics", "API", "Integrations", "AI Analysis"]'::jsonb,
    'large'
  );
```

---

## 🚀 PASO 7: TESTING (10 min)

### 7.1 Iniciar App
```bash
npm run dev
```

### 7.2 Ir a Análisis IA
```
http://localhost:5173/ai-analysis
```

### 7.3 Ejecutar Análisis
1. Click en "Ejecutar Análisis"
2. Esperar 20-30 segundos
3. Verificar que no hay errores

### 7.4 Verificar Nueva Tab
1. Click en tab "Competencia"
2. Verificar que muestra:
   - ✅ Posición en el mercado
   - ✅ Fuerza competitiva (score)
   - ✅ Insights por competidor
   - ✅ Comparación de precios
   - ✅ Feature gaps
   - ✅ Recomendaciones estratégicas
   - ✅ Evaluación de amenazas

### 7.5 Verificar Plan Free
1. Cambiar plan de organización a 'free':
```sql
UPDATE organizations 
SET plan = 'free' 
WHERE id = '[TU_ORG_ID]';
```
2. Ir a /ai-analysis
3. Tab "Competencia" debe mostrar mensaje de upgrade

### 7.6 Verificar Exportación
1. Ejecutar análisis
2. Click en "Descargar Reporte"
3. Seleccionar PDF
4. Verificar que descarga correctamente

---

## 🎨 PERSONALIZACIÓN OPCIONAL

### Añadir Página de Gestión de Competidores

Crear nueva página para gestionar competidores:

```tsx
// src/pages/CompetitorsManagement.tsx
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';

export default function CompetitorsManagement() {
  const { data: competitors } = useQuery({
    queryKey: ['competitors'],
    queryFn: async () => {
      const { data } = await supabase
        .from('competitors')
        .select('*')
        .order('name');
      return data;
    }
  });

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between">
        <h1 className="text-3xl font-bold">Competidores</h1>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Añadir Competidor
        </Button>
      </div>
      
      <div className="grid gap-4">
        {competitors?.map((comp) => (
          <div key={comp.id} className="border rounded-lg p-4">
            <h3 className="font-semibold">{comp.name}</h3>
            <p className="text-sm text-muted-foreground">{comp.website}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
```

Añadir ruta en `App.tsx`:
```tsx
<Route path="/competitors" element={
  <ProtectedRoute>
    <CompetitorsManagement />
  </ProtectedRoute>
} />
```

---

## 🔍 QUÉ ANALIZA LA IA

### 1. **Posición en el Mercado**
- Leader: Precios altos, muchas features
- Challenger: Buena posición pero no líder
- Follower: Precios competitivos, features estándar
- Nicher: Enfoque en nicho específico

### 2. **Key Insights**
Para cada competidor:
- ¿Qué hace mejor que nosotros?
- ¿Qué amenaza representa?
- ¿Qué oportunidad nos da?

### 3. **Pricing Comparison**
- Tu posición: Premium / Competitive / Budget
- Ventaja/desventaja en %
- Recomendación específica

### 4. **Feature Gaps**
Features que competidores tienen y tú NO:
- Prioridad: High / Medium / Low
- Quién lo tiene
- Impacto estimado

### 5. **Recomendaciones Estratégicas**
3-5 acciones concretas:
- Defenderse de amenazas
- Aprovechar oportunidades
- Diferenciarse

### 6. **Evaluación de Amenazas**
- Amenazas inmediatas (acción ahora)
- Amenazas emergentes (monitorear)
- Estrategias de mitigación

---

## 📊 EJEMPLO DE ANÁLISIS GENERADO

```json
{
  "competitive_analysis": {
    "market_position": "challenger",
    "competitive_strength": 72,
    "competitors_analyzed": 3,
    "key_insights": [
      {
        "competitor": "Competitor A",
        "insight": "Tienen integración nativa con Salesforce y HubSpot que nosotros no tenemos. Es su principal ventaja.",
        "threat_level": "high",
        "opportunity": "Podemos destacar nuestra UI más simple y moderna, que es más fácil de usar para equipos pequeños."
      },
      {
        "competitor": "Competitor B",
        "insight": "Su modelo freemium les da mucha tracción inicial, pero monetizan peor que nosotros.",
        "threat_level": "medium",
        "opportunity": "Podemos ofrecer trial extendido de 30 días para competir en adquisición."
      }
    ],
    "pricing_comparison": {
      "your_position": "competitive",
      "price_advantage": -5,
      "recommendation": "Estás 5% más barato que el promedio. Considera subir precios gradualmente mientras añades más features premium."
    },
    "feature_gaps": [
      {
        "feature": "Salesforce Integration",
        "competitors_with_it": ["Competitor A", "Competitor C"],
        "priority": "high",
        "estimated_impact": "Puede aumentar conversión de enterprise en 30%"
      },
      {
        "feature": "Mobile App",
        "competitors_with_it": ["Competitor B"],
        "priority": "medium",
        "estimated_impact": "Importante para usuarios remotos"
      }
    ],
    "strategic_recommendations": [
      "Desarrollar integración con Salesforce en Q1 para competir en enterprise",
      "Destacar análisis con IA como diferenciador único en marketing",
      "Subir precios 10% mientras añades feature de mobile app",
      "Crear contenido comparativo (tu producto vs competidores) para SEO"
    ],
    "threat_assessment": {
      "immediate_threats": [
        "Competitor A está bajando precios agresivamente para ganar market share"
      ],
      "emerging_threats": [
        "Competitor C está desarrollando feature de IA similar al nuestro"
      ],
      "mitigation_strategies": [
        "Acelerar desarrollo de features únicos de IA",
        "Mejorar messaging sobre ventajas vs Competitor A",
        "Lock-in de clientes con contratos anuales con descuento"
      ]
    }
  }
}
```

---

## 🐛 TROUBLESHOOTING

### Error: "competitive_analysis column does not exist"
```sql
-- Ejecutar:
ALTER TABLE ai_analysis_results 
ADD COLUMN competitive_analysis JSONB;
```

### Error: "competitors table does not exist"
```sql
-- Verificar que ejecutaste competitors-table.sql
SELECT * FROM competitors LIMIT 1;
```

### Error: "LOVABLE_API_KEY not configured"
```bash
# Configurar variable de entorno
supabase secrets set LOVABLE_API_KEY=tu_api_key_aqui
```

### Tab "Competencia" está vacío
1. Verificar que el plan NO sea 'free'
2. Verificar que hay competidores en la tabla
3. Ver console del navegador para errores

### IA no genera análisis competitivo
1. Verificar que hay competidores: `SELECT * FROM competitors`
2. Ver logs de la Edge Function: `supabase functions logs analyze-project-data-v3`
3. Verificar que el prompt incluye competidores

---

## ✅ CHECKLIST FINAL

```
SETUP:
[ ] SQL ejecutado en Supabase
[ ] Columna competitive_analysis añadida
[ ] Edge Function v3 desplegada
[ ] LOVABLE_API_KEY configurada
[ ] Componente AIAnalysis actualizado

DATOS:
[ ] Competidores de prueba añadidos
[ ] Plan de organización NO es 'free'
[ ] Usuario puede acceder a /ai-analysis

TESTING:
[ ] Análisis ejecuta sin errores
[ ] Tab "Competencia" muestra datos
[ ] Plan free muestra mensaje de upgrade
[ ] Exportación funciona
[ ] Límites por plan funcionan

OPCIONALES:
[ ] Página de gestión de competidores
[ ] Analytics de análisis competitivo
[ ] Cron job para análisis automático
```

---

## 🎯 MEJORAS FUTURAS

### 1. Scraping Automático de Competidores
```typescript
// Edge Function adicional
async function scrapeCompetitor(url: string) {
  // Scraping de website
  // Análisis de pricing
  // Detección de features
  // Actualización automática
}
```

### 2. Alertas de Cambios
```sql
-- Trigger cuando competidor cambia precio
CREATE OR REPLACE FUNCTION notify_price_change()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.min_price != NEW.min_price OR OLD.max_price != NEW.max_price THEN
    -- Enviar notificación
    PERFORM pg_notify('competitor_price_change', NEW.id::text);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
```

### 3. Comparaciones Visuales
- Gráficos de radar (features)
- Scatter plot (precio vs features)
- Timeline de cambios

### 4. Reportes Mensuales Automáticos
```typescript
// Cron job mensual
const generateMonthlyCompetitiveReport = async () => {
  // Analizar cambios del mes
  // Generar PDF
  // Enviar por email
};
```

---

## 📚 RECURSOS ADICIONALES

### Documentación Relevante:
- [Supabase Edge Functions](https://supabase.com/docs/guides/functions)
- [React Query](https://tanstack.com/query/latest)
- [Lovable AI Gateway](https://lovable.app/docs)

### Ejemplos de Uso:
- Ver `AIAnalysis-Updated.tsx` líneas 250-450 para la UI
- Ver `analyze-project-data-v3-edge-function.ts` líneas 200-400 para el prompt

---

## 🎉 ¡LISTO!

Ahora tu análisis con IA incluye:
- ✅ Análisis competitivo completo
- ✅ Límites por plan
- ✅ Insights accionables
- ✅ Exportación en PDF
- ✅ UI profesional

**Impacto esperado:**
- 📈 Mejor toma de decisiones estratégicas
- 💪 Ventaja competitiva clara
- 🎯 Justifica upgrade a Professional
- ⭐ Feature única en el mercado

**Tiempo de implementación:** 30-40 minutos

---

## 💬 SOPORTE

¿Dudas? ¿Errores? ¡Pregúntame! 🚀
