/**
 * COMPONENTE ACTUALIZADO: AIAnalysis con Análisis Competitivo
 * 
 * Path: src/pages/AIAnalysis.tsx (REEMPLAZAR)
 */

import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useCurrentOrganization } from '@/hooks/useCurrentOrganization';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Brain, 
  TrendingUp, 
  Users, 
  DollarSign, 
  AlertTriangle, 
  CheckCircle2, 
  Target,
  Loader2,
  Sparkles,
  TrendingDown,
  Shield,
  Zap,
  Building2, // ← NUEVO
  BarChart3  // ← NUEVO
} from 'lucide-react';
import { toast } from 'sonner';
import { ExportButton } from '@/components/ExportButton';

export default function AIAnalysis() {
  const { data: organization } = useCurrentOrganization();
  const queryClient = useQueryClient();
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Obtener último análisis
  const { data: latestAnalysis, isLoading } = useQuery({
    queryKey: ['ai-analysis', organization?.id],
    queryFn: async () => {
      if (!organization?.id) return null;

      const { data, error } = await supabase
        .from('ai_analysis_results')
        .select('*')
        .eq('organization_id', organization.id)
        .order('analyzed_at', { ascending: false })
        .limit(1)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      return data;
    },
    enabled: !!organization?.id,
  });

  // Ejecutar análisis
  const runAnalysisMutation = useMutation({
    mutationFn: async () => {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) throw new Error('No session');

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-project-data-v3`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session.access_token}`,
          },
        }
      );

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Error al ejecutar análisis');
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ai-analysis'] });
      toast.success('Análisis completado exitosamente');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Error al ejecutar análisis');
    },
  });

  const handleRunAnalysis = async () => {
    setIsAnalyzing(true);
    try {
      await runAnalysisMutation.mutateAsync();
    } finally {
      setIsAnalyzing(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Brain className="w-8 h-8 text-primary" />
            Análisis con IA
          </h1>
          <p className="text-muted-foreground mt-1">
            Insights accionables generados por inteligencia artificial
          </p>
        </div>

        <div className="flex gap-2">
          {latestAnalysis && (
            <ExportButton
              exportType="ai-analysis"
              data={latestAnalysis}
              metadata={{
                title: 'Análisis con IA',
                organizationName: organization?.name,
              }}
              availableFormats={['pdf']}
              buttonText="Descargar Reporte"
              variant="outline"
            />
          )}

          <Button
            onClick={handleRunAnalysis}
            disabled={isAnalyzing}
            className="gap-2"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Analizando...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                Ejecutar Análisis
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Límite de análisis alcanzado */}
      {!latestAnalysis && (
        <Alert>
          <AlertTriangle className="w-4 h-4" />
          <AlertDescription>
            No hay análisis disponibles. Ejecuta tu primer análisis haciendo clic en el botón "Ejecutar Análisis".
          </AlertDescription>
        </Alert>
      )}

      {/* Tabs con análisis */}
      {latestAnalysis && (
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Resumen</TabsTrigger>
            <TabsTrigger value="financial">Financiero</TabsTrigger>
            <TabsTrigger value="team">Equipo</TabsTrigger>
            <TabsTrigger value="competitive">Competencia</TabsTrigger> {/* ← NUEVO */}
            <TabsTrigger value="actions">Acciones</TabsTrigger>
          </TabsList>

          {/* Tab: Resumen */}
          <TabsContent value="overview" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Resumen Ejecutivo</CardTitle>
                <CardDescription>
                  Análisis generado el {new Date(latestAnalysis.analyzed_at).toLocaleDateString('es-ES')}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Scores principales */}
                <div className="grid md:grid-cols-3 gap-4">
                  {/* Salud Financiera */}
                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between mb-2">
                        <DollarSign className="w-5 h-5 text-green-500" />
                        <Badge
                          variant={
                            latestAnalysis.financial_health?.status === 'healthy'
                              ? 'default'
                              : latestAnalysis.financial_health?.status === 'warning'
                              ? 'secondary'
                              : 'destructive'
                          }
                        >
                          {latestAnalysis.financial_health?.status}
                        </Badge>
                      </div>
                      <h3 className="font-semibold mb-1">Salud Financiera</h3>
                      <div className="flex items-baseline gap-2">
                        <span className="text-3xl font-bold">
                          {latestAnalysis.financial_health?.score || 0}
                        </span>
                        <span className="text-sm text-muted-foreground">/100</span>
                      </div>
                      <Progress
                        value={latestAnalysis.financial_health?.score || 0}
                        className="mt-2"
                      />
                    </CardContent>
                  </Card>

                  {/* Rendimiento Equipo */}
                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between mb-2">
                        <Users className="w-5 h-5 text-blue-500" />
                        <Badge variant="outline">
                          {latestAnalysis.team_performance?.team_health}
                        </Badge>
                      </div>
                      <h3 className="font-semibold mb-1">Equipo</h3>
                      <div className="flex items-baseline gap-2">
                        <span className="text-3xl font-bold">
                          {latestAnalysis.team_performance?.productivity_score || 0}
                        </span>
                        <span className="text-sm text-muted-foreground">/100</span>
                      </div>
                      <Progress
                        value={latestAnalysis.team_performance?.productivity_score || 0}
                        className="mt-2"
                      />
                    </CardContent>
                  </Card>

                  {/* Posición Competitiva ← NUEVO */}
                  {latestAnalysis.competitive_analysis && (
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-center justify-between mb-2">
                          <Building2 className="w-5 h-5 text-purple-500" />
                          <Badge variant="outline">
                            {latestAnalysis.competitive_analysis.market_position}
                          </Badge>
                        </div>
                        <h3 className="font-semibold mb-1">Competencia</h3>
                        <div className="flex items-baseline gap-2">
                          <span className="text-3xl font-bold">
                            {latestAnalysis.competitive_analysis.competitive_strength || 0}
                          </span>
                          <span className="text-sm text-muted-foreground">/100</span>
                        </div>
                        <Progress
                          value={latestAnalysis.competitive_analysis.competitive_strength || 0}
                          className="mt-2"
                        />
                      </CardContent>
                    </Card>
                  )}
                </div>

                {/* Feedback Honesto */}
                <Card className="border-primary/20 bg-primary/5">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5" />
                      Feedback Honesto
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm leading-relaxed whitespace-pre-line">
                      {latestAnalysis.honest_feedback}
                    </p>
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Financiero */}
          <TabsContent value="financial" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5" />
                  Salud Financiera
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {latestAnalysis.financial_health && (
                  <>
                    {/* Métricas Clave */}
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Burn Rate</p>
                        <p className="text-2xl font-bold">
                          €{latestAnalysis.financial_health.key_metrics?.burn_rate?.toLocaleString() || '0'}
                          <span className="text-sm font-normal text-muted-foreground">/mes</span>
                        </p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Runway</p>
                        <p className="text-2xl font-bold">
                          {latestAnalysis.financial_health.key_metrics?.runway || 0}
                          <span className="text-sm font-normal text-muted-foreground"> meses</span>
                        </p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Cash Flow</p>
                        <p className="text-2xl font-bold">
                          €{latestAnalysis.financial_health.key_metrics?.cash_flow?.toLocaleString() || '0'}
                        </p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Tendencia Revenue</p>
                        <Badge
                          variant={
                            latestAnalysis.financial_health.key_metrics?.revenue_trend === 'up'
                              ? 'default'
                              : latestAnalysis.financial_health.key_metrics?.revenue_trend === 'stable'
                              ? 'secondary'
                              : 'destructive'
                          }
                          className="text-lg"
                        >
                          {latestAnalysis.financial_health.key_metrics?.revenue_trend === 'up' && '↗'}
                          {latestAnalysis.financial_health.key_metrics?.revenue_trend === 'stable' && '→'}
                          {latestAnalysis.financial_health.key_metrics?.revenue_trend === 'down' && '↘'}
                          {' '}
                          {latestAnalysis.financial_health.key_metrics?.revenue_trend}
                        </Badge>
                      </div>
                    </div>

                    {/* Alertas */}
                    {latestAnalysis.financial_health.alerts?.length > 0 && (
                      <div className="space-y-2">
                        <h4 className="font-semibold flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4 text-yellow-500" />
                          Alertas
                        </h4>
                        <div className="space-y-2">
                          {latestAnalysis.financial_health.alerts.map((alert: string, index: number) => (
                            <Alert key={index} variant="destructive">
                              <AlertDescription>{alert}</AlertDescription>
                            </Alert>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Recomendaciones */}
                    {latestAnalysis.financial_health.recommendations?.length > 0 && (
                      <div className="space-y-2">
                        <h4 className="font-semibold flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-green-500" />
                          Recomendaciones
                        </h4>
                        <ul className="space-y-1">
                          {latestAnalysis.financial_health.recommendations.map((rec: string, index: number) => (
                            <li key={index} className="text-sm flex items-start gap-2">
                              <span className="text-primary mt-1">•</span>
                              <span>{rec}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Equipo */}
          <TabsContent value="team" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Rendimiento del Equipo
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {latestAnalysis.team_performance && (
                  <>
                    {/* Stats */}
                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Productividad</p>
                        <p className="text-2xl font-bold">
                          {latestAnalysis.team_performance.productivity_score}
                          <span className="text-sm font-normal text-muted-foreground">/100</span>
                        </p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Tasa Completación</p>
                        <p className="text-2xl font-bold">
                          {latestAnalysis.team_performance.completion_rate}%
                        </p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Tareas Completadas</p>
                        <p className="text-2xl font-bold">
                          {latestAnalysis.team_performance.completed_tasks}
                        </p>
                      </div>
                    </div>

                    {/* Top Performers */}
                    {latestAnalysis.team_performance.top_performers?.length > 0 && (
                      <div className="space-y-2">
                        <h4 className="font-semibold flex items-center gap-2">
                          <TrendingUp className="w-4 h-4 text-green-500" />
                          Top Performers
                        </h4>
                        <div className="space-y-2">
                          {latestAnalysis.team_performance.top_performers.map((performer: any, index: number) => (
                            <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                              <span className="font-medium">{performer.name}</span>
                              <Badge>{performer.score} puntos</Badge>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Áreas de Mejora */}
                    {latestAnalysis.team_performance.areas_of_improvement?.length > 0 && (
                      <div className="space-y-2">
                        <h4 className="font-semibold flex items-center gap-2">
                          <Target className="w-4 h-4 text-orange-500" />
                          Áreas de Mejora
                        </h4>
                        <ul className="space-y-1">
                          {latestAnalysis.team_performance.areas_of_improvement.map((area: string, index: number) => (
                            <li key={index} className="text-sm flex items-start gap-2">
                              <span className="text-primary mt-1">•</span>
                              <span>{area}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tab: Competencia ← NUEVO Y MUY IMPORTANTE */}
          <TabsContent value="competitive" className="space-y-4">
            {latestAnalysis.competitive_analysis ? (
              <>
                {/* Card de Posición en el Mercado */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Building2 className="w-5 h-5" />
                      Posición en el Mercado
                    </CardTitle>
                    <CardDescription>
                      {latestAnalysis.competitive_analysis.competitors_analyzed} competidores analizados
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Posición</p>
                        <Badge className="text-lg" variant="outline">
                          {latestAnalysis.competitive_analysis.market_position}
                        </Badge>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Fuerza Competitiva</p>
                        <p className="text-2xl font-bold">
                          {latestAnalysis.competitive_analysis.competitive_strength}/100
                        </p>
                        <Progress value={latestAnalysis.competitive_analysis.competitive_strength} />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Insights por Competidor */}
                {latestAnalysis.competitive_analysis.key_insights?.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <BarChart3 className="w-5 h-5" />
                        Insights Clave por Competidor
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {latestAnalysis.competitive_analysis.key_insights.map((insight: any, index: number) => (
                        <Card key={index} className="border-l-4" style={{
                          borderLeftColor: insight.threat_level === 'high' ? '#ef4444' : 
                                          insight.threat_level === 'medium' ? '#f59e0b' : '#22c55e'
                        }}>
                          <CardContent className="pt-4">
                            <div className="flex items-start justify-between mb-2">
                              <h4 className="font-semibold">{insight.competitor}</h4>
                              <Badge variant={
                                insight.threat_level === 'high' ? 'destructive' :
                                insight.threat_level === 'medium' ? 'secondary' : 'default'
                              }>
                                {insight.threat_level} threat
                              </Badge>
                            </div>
                            <p className="text-sm mb-2">{insight.insight}</p>
                            {insight.opportunity && (
                              <div className="flex items-start gap-2 mt-2 p-2 bg-green-50 dark:bg-green-950 rounded">
                                <Zap className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                <p className="text-sm text-green-700 dark:text-green-300">
                                  <strong>Oportunidad:</strong> {insight.opportunity}
                                </p>
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                    </CardContent>
                  </Card>
                )}

                {/* Comparación de Precios */}
                {latestAnalysis.competitive_analysis.pricing_comparison && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <DollarSign className="w-5 h-5" />
                        Análisis de Precios
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Tu Posición</p>
                          <Badge className="text-lg" variant="outline">
                            {latestAnalysis.competitive_analysis.pricing_comparison.your_position}
                          </Badge>
                        </div>
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">vs Promedio</p>
                          <p className="text-2xl font-bold">
                            {latestAnalysis.competitive_analysis.pricing_comparison.price_advantage > 0 ? '+' : ''}
                            {latestAnalysis.competitive_analysis.pricing_comparison.price_advantage}%
                          </p>
                        </div>
                      </div>
                      <Alert>
                        <AlertDescription>
                          {latestAnalysis.competitive_analysis.pricing_comparison.recommendation}
                        </AlertDescription>
                      </Alert>
                    </CardContent>
                  </Card>
                )}

                {/* Feature Gaps */}
                {latestAnalysis.competitive_analysis.feature_gaps?.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Target className="w-5 h-5" />
                        Features que nos Faltan
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {latestAnalysis.competitive_analysis.feature_gaps.map((gap: any, index: number) => (
                        <div key={index} className="p-3 border rounded-lg space-y-2">
                          <div className="flex items-start justify-between">
                            <h4 className="font-semibold">{gap.feature}</h4>
                            <Badge variant={
                              gap.priority === 'high' ? 'destructive' :
                              gap.priority === 'medium' ? 'secondary' : 'outline'
                            }>
                              {gap.priority}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            Lo tienen: {gap.competitors_with_it.join(', ')}
                          </p>
                          <p className="text-sm">
                            <strong>Impacto estimado:</strong> {gap.estimated_impact}
                          </p>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                )}

                {/* Recomendaciones Estratégicas */}
                {latestAnalysis.competitive_analysis.strategic_recommendations?.length > 0 && (
                  <Card className="border-primary/20 bg-primary/5">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Sparkles className="w-5 h-5" />
                        Recomendaciones Estratégicas
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {latestAnalysis.competitive_analysis.strategic_recommendations.map((rec: string, index: number) => (
                          <li key={index} className="flex items-start gap-2">
                            <CheckCircle2 className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                            <span className="text-sm">{rec}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                )}

                {/* Evaluación de Amenazas */}
                {latestAnalysis.competitive_analysis.threat_assessment && (
                  <Card className="border-red-200 dark:border-red-900">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Shield className="w-5 h-5 text-red-500" />
                        Evaluación de Amenazas
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {/* Amenazas Inmediatas */}
                      {latestAnalysis.competitive_analysis.threat_assessment.immediate_threats?.length > 0 && (
                        <div className="space-y-2">
                          <h4 className="font-semibold text-red-600 dark:text-red-400">
                            ⚠️ Amenazas Inmediatas
                          </h4>
                          <ul className="space-y-1 ml-4">
                            {latestAnalysis.competitive_analysis.threat_assessment.immediate_threats.map((threat: string, index: number) => (
                              <li key={index} className="text-sm">• {threat}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* Amenazas Emergentes */}
                      {latestAnalysis.competitive_analysis.threat_assessment.emerging_threats?.length > 0 && (
                        <div className="space-y-2">
                          <h4 className="font-semibold text-orange-600 dark:text-orange-400">
                            🔸 Amenazas Emergentes
                          </h4>
                          <ul className="space-y-1 ml-4">
                            {latestAnalysis.competitive_analysis.threat_assessment.emerging_threats.map((threat: string, index: number) => (
                              <li key={index} className="text-sm">• {threat}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* Estrategias de Mitigación */}
                      {latestAnalysis.competitive_analysis.threat_assessment.mitigation_strategies?.length > 0 && (
                        <div className="space-y-2">
                          <h4 className="font-semibold text-green-600 dark:text-green-400">
                            ✅ Estrategias de Mitigación
                          </h4>
                          <ul className="space-y-1 ml-4">
                            {latestAnalysis.competitive_analysis.threat_assessment.mitigation_strategies.map((strategy: string, index: number) => (
                              <li key={index} className="text-sm">• {strategy}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
              </>
            ) : (
              <Alert>
                <Building2 className="w-4 h-4" />
                <AlertDescription className="space-y-2">
                  <p>
                    <strong>Análisis competitivo no disponible en tu plan.</strong>
                  </p>
                  <p className="text-sm">
                    Upgrade a Professional o superior para obtener análisis detallado de tus competidores,
                    comparativas de precios, feature gaps, y recomendaciones estratégicas.
                  </p>
                </AlertDescription>
              </Alert>
            )}
          </TabsContent>

          {/* Tab: Acciones */}
          <TabsContent value="actions" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5" />
                  Plan de Acción
                </CardTitle>
                <CardDescription>
                  Tareas priorizadas para mejorar tu negocio
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {latestAnalysis.action_items?.map((item: any, index: number) => (
                  <Card
                    key={index}
                    className="border-l-4"
                    style={{
                      borderLeftColor:
                        item.priority === 'critical'
                          ? '#ef4444'
                          : item.priority === 'high'
                          ? '#f59e0b'
                          : item.priority === 'medium'
                          ? '#3b82f6'
                          : '#6b7280',
                    }}
                  >
                    <CardContent className="pt-4">
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-semibold">{item.title}</h4>
                        <div className="flex gap-2">
                          <Badge
                            variant={
                              item.priority === 'critical' || item.priority === 'high'
                                ? 'destructive'
                                : 'secondary'
                            }
                          >
                            {item.priority}
                          </Badge>
                          <Badge variant="outline">{item.complexity}</Badge>
                        </div>
                      </div>
                      <p className="text-sm mb-2">{item.description}</p>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>
                          📅 Deadline: {new Date(item.deadline).toLocaleDateString('es-ES')}
                        </span>
                        <span>📈 Impacto: {item.estimated_impact}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </CardContent>
            </Card>

            {/* Proyecciones */}
            {latestAnalysis.growth_projections && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5" />
                    Proyecciones de Crecimiento (12 meses)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-4">
                    {['conservative', 'realistic', 'optimistic'].map((scenario) => (
                      <Card key={scenario} className="bg-muted/50">
                        <CardContent className="pt-4">
                          <h4 className="font-semibold capitalize mb-3">{scenario}</h4>
                          <div className="space-y-2">
                            <div>
                              <p className="text-xs text-muted-foreground">Revenue</p>
                              <p className="text-xl font-bold">
                                €
                                {latestAnalysis.growth_projections[
                                  scenario
                                ].revenue_12m.toLocaleString()}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Clientes</p>
                              <p className="text-xl font-bold">
                                {latestAnalysis.growth_projections[
                                  scenario
                                ].customers_12m.toLocaleString()}
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}
