# 🎨 DESCONOCIDOS SELECTOS - Sistema de Diseño Enterprise

## Filosofía de Diseño

**"Claridad con Carácter"** - Un sistema que combina la profesionalidad enterprise con una personalidad distintiva y memorable.

---

## 🎨 Paleta de Colores

### Colores Principales

| Nombre | HSL | Hex | Uso |
|--------|-----|-----|-----|
| **Midnight** | `222 47% 11%` | `#0f172a` | Texto principal, fondos dark |
| **Slate** | `215 20% 65%` | `#94a3b8` | Texto secundario |
| **Ocean** | `217 91% 60%` | `#3b82f6` | Primary - Acciones principales |
| **Ocean Dark** | `221 83% 53%` | `#2563eb` | Primary hover |
| **Emerald** | `160 84% 39%` | `#10b981` | Success - Confirmaciones |
| **Amber** | `38 92% 50%` | `#f59e0b` | Warning - Alertas |
| **Rose** | `0 84% 60%` | `#ef4444` | Destructive - Errores |
| **Violet** | `258 90% 66%` | `#8b5cf6` | Accent - Destacados especiales |

### Fondos y Superficies

| Nombre | Light Mode | Dark Mode | Uso |
|--------|------------|-----------|-----|
| **Background** | `#fafbfc` | `#0f172a` | Fondo de página |
| **Surface** | `#ffffff` | `#1e293b` | Cards, modales |
| **Surface Elevated** | `#ffffff` | `#334155` | Elementos elevados |
| **Muted** | `#f1f5f9` | `#1e293b` | Fondos sutiles |

### Gradientes

```css
/* Hero Gradient - Para headers y CTAs destacados */
--gradient-hero: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);

/* Surface Gradient - Para cards premium */
--gradient-surface: linear-gradient(180deg, rgba(59,130,246,0.05) 0%, transparent 100%);

/* Success Gradient */
--gradient-success: linear-gradient(135deg, #10b981 0%, #059669 100%);
```

---

## 📝 Tipografía

### Fuentes

```css
/* Display & Headings */
font-family: 'Plus Jakarta Sans', sans-serif;

/* Body & UI */
font-family: 'Inter', sans-serif;

/* Monospace (código, números) */
font-family: 'JetBrains Mono', monospace;
```

### Escala Tipográfica

| Nombre | Tamaño | Line Height | Weight | Uso |
|--------|--------|-------------|--------|-----|
| `display-2xl` | 4.5rem (72px) | 1 | 800 | Hero headlines |
| `display-xl` | 3.75rem (60px) | 1 | 700 | Page titles |
| `display-lg` | 3rem (48px) | 1.1 | 700 | Section headers |
| `h1` | 2.25rem (36px) | 1.2 | 700 | Main headings |
| `h2` | 1.875rem (30px) | 1.25 | 600 | Section titles |
| `h3` | 1.5rem (24px) | 1.3 | 600 | Card titles |
| `h4` | 1.25rem (20px) | 1.4 | 600 | Subsections |
| `body-lg` | 1.125rem (18px) | 1.6 | 400 | Lead paragraphs |
| `body` | 1rem (16px) | 1.6 | 400 | Body text |
| `body-sm` | 0.875rem (14px) | 1.5 | 400 | Secondary text |
| `caption` | 0.75rem (12px) | 1.4 | 500 | Labels, captions |
| `overline` | 0.75rem (12px) | 1.4 | 600 | Category labels |

---

## 📐 Espaciado

### Sistema de 4px

```
4px   = 0.25rem  = space-1
8px   = 0.5rem   = space-2
12px  = 0.75rem  = space-3
16px  = 1rem     = space-4
20px  = 1.25rem  = space-5
24px  = 1.5rem   = space-6
32px  = 2rem     = space-8
40px  = 2.5rem   = space-10
48px  = 3rem     = space-12
64px  = 4rem     = space-16
80px  = 5rem     = space-20
96px  = 6rem     = space-24
```

### Contenedores

| Nombre | Max Width | Uso |
|--------|-----------|-----|
| `container-sm` | 640px | Formularios, modales |
| `container-md` | 768px | Contenido de lectura |
| `container-lg` | 1024px | Dashboards compactos |
| `container-xl` | 1280px | Dashboards amplios |
| `container-2xl` | 1536px | Full-width layouts |

---

## 🔲 Border Radius

```css
--radius-sm: 0.375rem;   /* 6px - Botones pequeños, badges */
--radius-md: 0.5rem;     /* 8px - Inputs, botones */
--radius-lg: 0.75rem;    /* 12px - Cards pequeñas */
--radius-xl: 1rem;       /* 16px - Cards, modales */
--radius-2xl: 1.5rem;    /* 24px - Cards destacadas */
--radius-full: 9999px;   /* Circular - Avatars, pills */
```

---

## 🌑 Sombras

```css
/* Sutil - Para separación ligera */
--shadow-xs: 0 1px 2px 0 rgb(0 0 0 / 0.05);

/* Pequeña - Botones, inputs */
--shadow-sm: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);

/* Media - Cards */
--shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);

/* Grande - Modales, dropdowns */
--shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);

/* Extra grande - Elementos flotantes */
--shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);

/* Glow - Para elementos destacados */
--shadow-glow: 0 0 20px -5px var(--primary);
--shadow-glow-success: 0 0 20px -5px var(--success);
```

---

## ✨ Animaciones

### Duraciones

```css
--duration-fast: 150ms;
--duration-normal: 200ms;
--duration-slow: 300ms;
--duration-slower: 500ms;
```

### Easings

```css
--ease-out: cubic-bezier(0.33, 1, 0.68, 1);
--ease-in-out: cubic-bezier(0.65, 0, 0.35, 1);
--ease-bounce: cubic-bezier(0.34, 1.56, 0.64, 1);
--ease-spring: cubic-bezier(0.175, 0.885, 0.32, 1.275);
```

### Animaciones Comunes

```css
/* Fade In */
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

/* Slide Up */
@keyframes slideUp {
  from { 
    opacity: 0; 
    transform: translateY(10px); 
  }
  to { 
    opacity: 1; 
    transform: translateY(0); 
  }
}

/* Scale In */
@keyframes scaleIn {
  from { 
    opacity: 0; 
    transform: scale(0.95); 
  }
  to { 
    opacity: 1; 
    transform: scale(1); 
  }
}

/* Pulse Glow */
@keyframes pulseGlow {
  0%, 100% { box-shadow: 0 0 0 0 var(--primary); }
  50% { box-shadow: 0 0 20px -5px var(--primary); }
}
```

---

## 📱 Breakpoints

```css
sm: 640px   /* Mobile landscape */
md: 768px   /* Tablet */
lg: 1024px  /* Desktop small */
xl: 1280px  /* Desktop */
2xl: 1536px /* Desktop large */
```

---

## 🧩 Componentes

### Botones

| Variante | Uso |
|----------|-----|
| `primary` | Acciones principales (Guardar, Crear) |
| `secondary` | Acciones secundarias |
| `outline` | Acciones terciarias |
| `ghost` | Navegación, acciones sutiles |
| `destructive` | Eliminar, cancelar |
| `success` | Confirmaciones positivas |

### Cards

| Variante | Uso |
|----------|-----|
| `default` | Cards estándar |
| `elevated` | Cards con más prominencia |
| `interactive` | Cards clickeables |
| `stats` | KPIs y métricas |
| `premium` | Features premium |

### Badges

| Variante | Uso |
|----------|-----|
| `default` | Info neutral |
| `primary` | Destacado |
| `success` | Estado positivo |
| `warning` | Atención requerida |
| `destructive` | Estado crítico |
| `outline` | Sutil |

---

## 🎯 Principios de UX

### Jerarquía Visual
1. **Un foco principal** por pantalla
2. **Agrupación lógica** de elementos relacionados
3. **Espacio negativo** generoso para respirar
4. **Contraste** claro entre niveles de importancia

### Feedback
1. **Inmediato** - Hover states en 150ms
2. **Confirmación** - Toast para acciones completadas
3. **Progreso** - Indicadores claros para cargas
4. **Error** - Mensajes específicos y accionables

### Navegación
1. **Sidebar fijo** - Acceso constante a secciones principales
2. **Breadcrumbs** - Contexto de ubicación
3. **Búsqueda global** - Acceso rápido a todo
4. **Atajos de teclado** - Para usuarios avanzados

### Consistencia
1. **Mismos patrones** para acciones similares
2. **Misma terminología** en toda la app
3. **Mismos colores** para significados similares
4. **Mismas animaciones** para interacciones similares

---

## 📋 Checklist de Implementación

### CSS Variables
- [ ] Colores actualizados en `:root`
- [ ] Dark mode variables
- [ ] Gradientes definidos
- [ ] Sombras configuradas
- [ ] Animaciones creadas

### Tailwind Config
- [ ] Colores extendidos
- [ ] Tipografía configurada
- [ ] Espaciado personalizado
- [ ] Animaciones añadidas

### Componentes
- [ ] AppLayout con Sidebar
- [ ] Header mejorado
- [ ] Cards rediseñadas
- [ ] Botones actualizados
- [ ] Badges actualizados
- [ ] Inputs mejorados

### Páginas
- [ ] Home rediseñado
- [ ] Dashboard mejorado
- [ ] Navegación consistente
- [ ] Responsive verificado
