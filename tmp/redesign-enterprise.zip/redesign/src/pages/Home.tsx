import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  BarChart3,
  Brain,
  Palette,
  ArrowRight,
  Sparkles,
  TrendingUp,
  Users,
  Zap,
  Trophy,
  Calendar,
  Target,
} from 'lucide-react';
import { cn } from '@/lib/utils';

const Home = () => {
  const { userProfile } = useAuth();
  const navigate = useNavigate();

  const sections = [
    {
      id: 'dashboard',
      title: 'Dashboard',
      description: 'Gestiona tus tareas, agenda semanal y ve tu progreso diario',
      icon: LayoutDashboard,
      path: '/dashboard',
      color: 'from-blue-500 to-cyan-500',
      stats: [
        { label: 'Tareas hoy', value: '5' },
        { label: 'Completadas', value: '3' },
      ],
    },
    {
      id: 'metrics',
      title: 'Métricas',
      description: 'KPIs, OKRs, CRM y Panel Financiero del negocio',
      icon: BarChart3,
      path: '/metrics',
      color: 'from-emerald-500 to-teal-500',
      stats: [
        { label: 'OKRs activos', value: '4' },
        { label: 'Leads', value: '23' },
      ],
    },
    {
      id: 'ai',
      title: 'Análisis IA',
      description: 'Insights profundos, proyecciones y recomendaciones accionables',
      icon: Brain,
      path: '/ai-analysis',
      color: 'from-violet-500 to-purple-600',
      badge: 'PRO',
      stats: [
        { label: 'Score', value: '78' },
        { label: 'Alertas', value: '2' },
      ],
    },
    {
      id: 'tools',
      title: 'Herramientas',
      description: 'Herramientas visuales, práctica y calculadoras',
      icon: Palette,
      path: '/herramientas-hub',
      color: 'from-pink-500 to-rose-500',
      stats: [
        { label: 'Disponibles', value: '12' },
        { label: 'Usadas', value: '8' },
      ],
    },
  ];

  const quickActions = [
    { icon: Calendar, label: 'Ver agenda', path: '/dashboard/agenda' },
    { icon: Target, label: 'Mis OKRs', path: '/metrics/okrs' },
    { icon: Users, label: 'Pipeline', path: '/metrics/crm' },
    { icon: Trophy, label: 'Ranking', path: '/gamification' },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4 py-8 space-y-10">
        {/* Hero Section */}
        <section className="text-center space-y-6 py-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium">
            <Sparkles className="h-4 w-4" />
            Plataforma de Gestión Empresarial
          </div>
          
          <h1 className="text-display-lg text-balance">
            Hola, <span className="text-gradient-primary">{userProfile?.full_name?.split(' ')[0] || 'Usuario'}</span>
          </h1>
          
          <p className="text-body-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            Tu centro de control para gestionar tareas, métricas, OKRs y más.
            Selecciona una sección para comenzar.
          </p>

          {/* Quick Actions */}
          <div className="flex flex-wrap justify-center gap-3 pt-4">
            {quickActions.map((action) => (
              <Button
                key={action.path}
                variant="outline"
                className="gap-2"
                onClick={() => navigate(action.path)}
              >
                <action.icon className="h-4 w-4" />
                {action.label}
              </Button>
            ))}
          </div>
        </section>

        {/* Main Sections Grid */}
        <section className="grid gap-6 md:grid-cols-2">
          {sections.map((section, index) => {
            const Icon = section.icon;
            return (
              <Card
                key={section.id}
                className={cn(
                  'group relative overflow-hidden cursor-pointer transition-all duration-300',
                  'hover:shadow-xl hover:-translate-y-1 border-2 hover:border-primary/20',
                  'animate-slide-up'
                )}
                style={{ animationDelay: `${index * 100}ms` }}
                onClick={() => navigate(section.path)}
              >
                {/* Background gradient overlay */}
                <div
                  className={cn(
                    'absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500',
                    `bg-gradient-to-br ${section.color}`
                  )}
                  style={{ opacity: 0.03 }}
                />

                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div
                      className={cn(
                        'w-14 h-14 rounded-2xl flex items-center justify-center',
                        'bg-gradient-to-br shadow-lg',
                        section.color
                      )}
                    >
                      <Icon className="w-7 h-7 text-white" />
                    </div>
                    {section.badge && (
                      <Badge className="bg-gradient-primary text-white border-0">
                        {section.badge}
                      </Badge>
                    )}
                  </div>
                  <CardTitle className="text-xl mt-4 group-hover:text-primary transition-colors">
                    {section.title}
                  </CardTitle>
                  <CardDescription className="text-base">
                    {section.description}
                  </CardDescription>
                </CardHeader>

                <CardContent>
                  {/* Stats */}
                  <div className="flex gap-6 mb-4">
                    {section.stats.map((stat) => (
                      <div key={stat.label}>
                        <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                        <p className="text-xs text-muted-foreground">{stat.label}</p>
                      </div>
                    ))}
                  </div>

                  {/* CTA */}
                  <div className="flex items-center text-sm font-medium text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                    <span>Explorar</span>
                    <ArrowRight className="ml-1 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </section>

        {/* Quick Insights */}
        <section className="grid gap-4 md:grid-cols-3">
          <Card className="p-6 bg-gradient-to-br from-success/10 to-success/5 border-success/20">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-success/20 flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-success" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Crecimiento</p>
                <p className="text-2xl font-bold text-success">+12%</p>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
                <Zap className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Productividad</p>
                <p className="text-2xl font-bold text-primary">87%</p>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-warning/10 to-warning/5 border-warning/20">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-warning/20 flex items-center justify-center">
                <Trophy className="h-6 w-6 text-warning" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Racha</p>
                <p className="text-2xl font-bold text-warning">7 días</p>
              </div>
            </div>
          </Card>
        </section>
      </div>
    </div>
  );
};

export default Home;
