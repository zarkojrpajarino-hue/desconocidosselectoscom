import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { PageHeader } from '@/components/ui-custom/PageHeader';
import { StatCard, StatsGrid } from '@/components/ui-custom/StatCard';
import {
  CheckCircle2,
  Clock,
  Target,
  TrendingUp,
  Calendar,
  Trophy,
  Flame,
  ArrowRight,
  Play,
  Users,
  BarChart3,
  Zap,
  Star,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface Task {
  id: string;
  title: string;
  description: string;
  area: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'pending' | 'in_progress' | 'completed';
  scheduled_date?: string;
  scheduled_start?: string;
  scheduled_end?: string;
}

interface TeamMember {
  id: string;
  full_name: string;
  avatar_url?: string;
  tasks_completed: number;
  tasks_total: number;
  streak: number;
}

const DashboardHome = () => {
  const { user, userProfile } = useAuth();
  const navigate = useNavigate();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [stats, setStats] = useState({
    tasksCompleted: 0,
    tasksTotal: 8,
    weekProgress: 0,
    streak: 0,
    points: 0,
    rank: 1,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, [user]);

  const fetchDashboardData = async () => {
    if (!user) return;
    setLoading(false);
    // TODO: Fetch real data from Supabase
  };

  // Mock data for demo
  const todayTasks: Task[] = [
    {
      id: '1',
      title: 'Revisar propuesta de cliente',
      description: 'Revisar y aprobar la propuesta enviada a Empresa XYZ',
      area: 'Ventas',
      priority: 'high',
      status: 'pending',
      scheduled_start: '09:00',
      scheduled_end: '10:30',
    },
    {
      id: '2',
      title: 'Reunión de equipo',
      description: 'Sync semanal con el equipo de desarrollo',
      area: 'Equipo',
      priority: 'medium',
      status: 'in_progress',
      scheduled_start: '11:00',
      scheduled_end: '12:00',
    },
    {
      id: '3',
      title: 'Actualizar OKRs',
      description: 'Actualizar el progreso de los objetivos del Q4',
      area: 'Estrategia',
      priority: 'medium',
      status: 'pending',
      scheduled_start: '14:00',
      scheduled_end: '15:00',
    },
  ];

  const mockTeamMembers: TeamMember[] = [
    { id: '1', full_name: 'Ana García', tasks_completed: 7, tasks_total: 8, streak: 12 },
    { id: '2', full_name: 'Carlos López', tasks_completed: 6, tasks_total: 8, streak: 8 },
    { id: '3', full_name: 'María Rodríguez', tasks_completed: 8, tasks_total: 8, streak: 15 },
    { id: '4', full_name: 'Juan Martínez', tasks_completed: 5, tasks_total: 8, streak: 3 },
  ];

  const priorityColors = {
    low: 'bg-muted text-muted-foreground',
    medium: 'bg-info/10 text-info border-info/20',
    high: 'bg-warning/10 text-warning border-warning/20',
    urgent: 'bg-destructive/10 text-destructive border-destructive/20',
  };

  const greetingMessage = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Buenos días';
    if (hour < 18) return 'Buenas tardes';
    return 'Buenas noches';
  };

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary via-primary to-accent p-8 text-white">
        <div className="relative z-10">
          <p className="text-white/80 text-sm font-medium mb-1">
            {greetingMessage()},
          </p>
          <h1 className="text-3xl font-bold mb-2">
            {userProfile?.full_name || 'Usuario'}
          </h1>
          <p className="text-white/80 max-w-md">
            Tienes <span className="font-semibold text-white">3 tareas</span> pendientes para hoy.
            ¡Vamos a completarlas!
          </p>
          <div className="flex items-center gap-4 mt-6">
            <Button 
              variant="secondary" 
              className="bg-white text-primary hover:bg-white/90"
              onClick={() => navigate('/dashboard/agenda')}
            >
              <Calendar className="mr-2 h-4 w-4" />
              Ver agenda
            </Button>
            <Button 
              variant="ghost" 
              className="text-white hover:bg-white/10"
            >
              <Play className="mr-2 h-4 w-4" />
              Comenzar tarea
            </Button>
          </div>
        </div>
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
        <div className="absolute bottom-0 right-20 w-32 h-32 bg-white/5 rounded-full translate-y-1/2" />
      </div>

      {/* Quick Stats */}
      <StatsGrid columns={4}>
        <StatCard
          title="Tareas Completadas"
          value={`${stats.tasksCompleted}/${stats.tasksTotal}`}
          subtitle="Esta semana"
          icon={<CheckCircle2 className="w-full h-full" />}
          variant="success"
          trend={{ value: 12, label: 'vs semana anterior' }}
        />
        <StatCard
          title="Progreso Semanal"
          value={`${stats.weekProgress}%`}
          subtitle="Meta: 100%"
          icon={<Target className="w-full h-full" />}
          variant="primary"
        />
        <StatCard
          title="Racha Actual"
          value={`${stats.streak} días`}
          subtitle="¡Sigue así!"
          icon={<Flame className="w-full h-full" />}
          variant="warning"
        />
        <StatCard
          title="Posición"
          value={`#${stats.rank}`}
          subtitle="En tu equipo"
          icon={<Trophy className="w-full h-full" />}
          onClick={() => navigate('/gamification')}
        />
      </StatsGrid>

      {/* Main Content Grid */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Today's Tasks - Takes 2 columns */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-h4">Tareas de Hoy</h2>
            <Button variant="ghost" size="sm" onClick={() => navigate('/dashboard/agenda')}>
              Ver todo
              <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </div>

          <div className="space-y-3">
            {todayTasks.map((task, index) => (
              <Card
                key={task.id}
                className={cn(
                  'card-interactive',
                  'animate-slide-up',
                )}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    {/* Time */}
                    <div className="flex-shrink-0 w-20 text-center">
                      <p className="text-sm font-semibold text-foreground">
                        {task.scheduled_start}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        - {task.scheduled_end}
                      </p>
                    </div>

                    {/* Divider */}
                    <div className="w-px h-12 bg-border self-center" />

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="font-medium text-foreground">
                            {task.title}
                          </h3>
                          <p className="text-sm text-muted-foreground line-clamp-1">
                            {task.description}
                          </p>
                        </div>
                        <Badge
                          variant="outline"
                          className={cn('flex-shrink-0', priorityColors[task.priority])}
                        >
                          {task.priority}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-3 mt-2">
                        <Badge variant="secondary" className="text-xs">
                          {task.area}
                        </Badge>
                        {task.status === 'in_progress' && (
                          <span className="flex items-center gap-1 text-xs text-primary">
                            <span className="relative flex h-2 w-2">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
                              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
                            </span>
                            En progreso
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Action */}
                    <Button variant="ghost" size="icon" className="flex-shrink-0">
                      <CheckCircle2 className="h-5 w-5" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-4">
            {[
              { icon: BarChart3, label: 'Métricas', path: '/metrics', color: 'text-blue-500' },
              { icon: Target, label: 'OKRs', path: '/metrics/okrs', color: 'text-emerald-500' },
              { icon: Users, label: 'CRM', path: '/metrics/crm', color: 'text-violet-500' },
              { icon: Zap, label: 'IA Analysis', path: '/ai-analysis', color: 'text-amber-500' },
            ].map((item) => (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className="flex items-center gap-3 p-4 rounded-xl bg-card border border-border hover:border-primary/30 hover:shadow-md transition-all"
              >
                <item.icon className={cn('h-5 w-5', item.color)} />
                <span className="font-medium text-sm">{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Right Sidebar */}
        <div className="space-y-6">
          {/* Team Progress */}
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Equipo</CardTitle>
                <Button variant="ghost" size="sm">
                  Ver todo
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {mockTeamMembers.slice(0, 4).map((member, index) => (
                <div
                  key={member.id}
                  className={cn(
                    'flex items-center gap-3 animate-slide-in-right',
                  )}
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="relative">
                    <Avatar className="h-9 w-9">
                      <AvatarImage src={member.avatar_url} />
                      <AvatarFallback className="text-xs bg-primary/10 text-primary">
                        {member.full_name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    {member.streak >= 10 && (
                      <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-warning flex items-center justify-center">
                        <Flame className="w-2.5 h-2.5 text-white" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">
                      {member.full_name}
                    </p>
                    <div className="flex items-center gap-2">
                      <Progress
                        value={(member.tasks_completed / member.tasks_total) * 100}
                        className="h-1.5 flex-1"
                      />
                      <span className="text-xs text-muted-foreground">
                        {member.tasks_completed}/{member.tasks_total}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Weekly Progress */}
          <Card className="card-premium">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Trophy className="h-5 w-5 text-warning" />
                Tu Progreso
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-4">
                <div className="relative inline-flex">
                  <svg className="w-32 h-32 transform -rotate-90">
                    <circle
                      cx="64"
                      cy="64"
                      r="56"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="12"
                      className="text-muted"
                    />
                    <circle
                      cx="64"
                      cy="64"
                      r="56"
                      fill="none"
                      stroke="url(#progressGradient)"
                      strokeWidth="12"
                      strokeLinecap="round"
                      strokeDasharray={`${(stats.weekProgress / 100) * 352} 352`}
                    />
                    <defs>
                      <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="hsl(var(--primary))" />
                        <stop offset="100%" stopColor="hsl(var(--accent))" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <span className="text-3xl font-bold">{stats.weekProgress}%</span>
                      <p className="text-xs text-muted-foreground">completado</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border">
                <div className="text-center">
                  <p className="text-2xl font-bold text-foreground">{stats.points}</p>
                  <p className="text-xs text-muted-foreground">Puntos</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-foreground">{stats.streak}</p>
                  <p className="text-xs text-muted-foreground">Días de racha</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Upcoming */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Clock className="h-5 w-5 text-muted-foreground" />
                Próximamente
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3 p-2 rounded-lg bg-muted/50">
                <div className="w-1 h-8 rounded-full bg-primary" />
                <div className="flex-1">
                  <p className="text-sm font-medium">Reunión de OKRs</p>
                  <p className="text-xs text-muted-foreground">Mañana, 10:00</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-2 rounded-lg bg-muted/50">
                <div className="w-1 h-8 rounded-full bg-success" />
                <div className="flex-1">
                  <p className="text-sm font-medium">Demo con cliente</p>
                  <p className="text-xs text-muted-foreground">Viernes, 15:00</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-2 rounded-lg bg-muted/50">
                <div className="w-1 h-8 rounded-full bg-warning" />
                <div className="flex-1">
                  <p className="text-sm font-medium">Entrega de sprint</p>
                  <p className="text-xs text-muted-foreground">Viernes, 18:00</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default DashboardHome;
