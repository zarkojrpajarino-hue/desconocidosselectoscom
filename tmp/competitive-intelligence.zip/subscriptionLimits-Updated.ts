/**
 * SUBSCRIPTION LIMITS - ACTUALIZADO CON ANÁLISIS COMPETITIVO
 * 
 * Path: src/constants/subscriptionLimits.ts (REEMPLAZAR)
 * 
 * Añade límites para:
 * - Análisis de competidores
 * - Máximo de competidores por plan
 * - Profundidad de análisis
 */

export interface PlanLimits {
  // Usuarios y Organizaciones
  max_users: number;
  max_organizations_owned: number;
  max_organizations_joined: number;
  
  // CRM
  max_leads_per_month: number;
  lead_scoring: boolean;
  pipeline_drag_drop: boolean;
  deal_velocity: boolean;
  pipeline_forecast: boolean;
  
  // OKRs
  max_okrs: number;
  okr_dependencies: boolean;
  okr_quarterly_view: boolean;
  okr_check_ins: boolean;
  okr_retrospectives: boolean;
  
  // Análisis IA
  max_ai_analyses_per_month: number;
  
  // Análisis Competitivo ← NUEVO
  include_competitor_analysis: boolean;
  max_competitors: number;
  competitor_analysis_depth: 'none' | 'basic' | 'standard' | 'advanced' | 'premium';
  competitor_analysis_frequency: 'manual' | 'monthly' | 'weekly' | 'daily' | 'realtime';
  competitor_price_alerts: boolean;
  competitor_feature_tracking: boolean;
  
  // Herramientas IA
  max_ai_tools: number;
  custom_ai_prompts: boolean;
  
  // Tareas
  available_phases: number[];
  task_swaps_per_week: number;
  collaborative_tasks: boolean;
  
  // Features Premium
  google_calendar_integration: boolean;
  export_csv: boolean;
  export_excel: boolean;
  export_pdf: boolean;
  api_access: 'none' | 'read' | 'read-write';
  white_label: boolean;
  custom_domain: boolean;
  priority_support: boolean;
  dedicated_account_manager: boolean;
  sla_guarantee: string;
}

export type SubscriptionPlan = 'free' | 'trial' | 'starter' | 'professional' | 'enterprise';

export const PLAN_LIMITS: Record<SubscriptionPlan, PlanLimits> = {
  // ==========================================
  // FREE / TRIAL
  // ==========================================
  free: {
    // Usuarios y Organizaciones
    max_users: 3,
    max_organizations_owned: 1,
    max_organizations_joined: 3,
    
    // CRM
    max_leads_per_month: 50,
    lead_scoring: false,
    pipeline_drag_drop: false,
    deal_velocity: false,
    pipeline_forecast: false,
    
    // OKRs
    max_okrs: 3,
    okr_dependencies: false,
    okr_quarterly_view: false,
    okr_check_ins: false,
    okr_retrospectives: false,
    
    // Análisis IA
    max_ai_analyses_per_month: 1,
    
    // Análisis Competitivo ← NUEVO
    include_competitor_analysis: false,
    max_competitors: 0,
    competitor_analysis_depth: 'none',
    competitor_analysis_frequency: 'manual',
    competitor_price_alerts: false,
    competitor_feature_tracking: false,
    
    // Herramientas IA
    max_ai_tools: 2,
    custom_ai_prompts: false,
    
    // Tareas
    available_phases: [1], // Solo Fase 1
    task_swaps_per_week: 3,
    collaborative_tasks: false,
    
    // Features Premium
    google_calendar_integration: false,
    export_csv: true,
    export_excel: false,
    export_pdf: false,
    api_access: 'none',
    white_label: false,
    custom_domain: false,
    priority_support: false,
    dedicated_account_manager: false,
    sla_guarantee: 'none',
  },

  // ==========================================
  // TRIAL (14 días)
  // ==========================================
  trial: {
    // Usuarios y Organizaciones
    max_users: 3,
    max_organizations_owned: 1,
    max_organizations_joined: 3,
    
    // CRM
    max_leads_per_month: 100,
    lead_scoring: true,
    pipeline_drag_drop: true,
    deal_velocity: false,
    pipeline_forecast: false,
    
    // OKRs
    max_okrs: 5,
    okr_dependencies: false,
    okr_quarterly_view: false,
    okr_check_ins: true,
    okr_retrospectives: false,
    
    // Análisis IA
    max_ai_analyses_per_month: 2,
    
    // Análisis Competitivo ← NUEVO (Limitado en trial)
    include_competitor_analysis: true,
    max_competitors: 1, // Solo 1 competidor para probar
    competitor_analysis_depth: 'basic',
    competitor_analysis_frequency: 'manual',
    competitor_price_alerts: false,
    competitor_feature_tracking: false,
    
    // Herramientas IA
    max_ai_tools: 4,
    custom_ai_prompts: false,
    
    // Tareas
    available_phases: [1, 2], // Fases 1-2
    task_swaps_per_week: 5,
    collaborative_tasks: true,
    
    // Features Premium
    google_calendar_integration: false,
    export_csv: true,
    export_excel: true,
    export_pdf: false,
    api_access: 'none',
    white_label: false,
    custom_domain: false,
    priority_support: false,
    dedicated_account_manager: false,
    sla_guarantee: 'none',
  },

  // ==========================================
  // STARTER - €129/mes
  // ==========================================
  starter: {
    // Usuarios y Organizaciones
    max_users: 10,
    max_organizations_owned: 1,
    max_organizations_joined: 5,
    
    // CRM
    max_leads_per_month: 1000,
    lead_scoring: true,
    pipeline_drag_drop: true,
    deal_velocity: false,
    pipeline_forecast: false,
    
    // OKRs
    max_okrs: 10,
    okr_dependencies: false,
    okr_quarterly_view: false,
    okr_check_ins: true,
    okr_retrospectives: false,
    
    // Análisis IA
    max_ai_analyses_per_month: 4,
    
    // Análisis Competitivo ← NUEVO
    include_competitor_analysis: true,
    max_competitors: 3, // Hasta 3 competidores
    competitor_analysis_depth: 'standard',
    competitor_analysis_frequency: 'weekly',
    competitor_price_alerts: true,
    competitor_feature_tracking: false,
    
    // Herramientas IA
    max_ai_tools: 4,
    custom_ai_prompts: false,
    
    // Tareas
    available_phases: [1, 2], // Fases 1-2
    task_swaps_per_week: 7,
    collaborative_tasks: true,
    
    // Features Premium
    google_calendar_integration: false,
    export_csv: true,
    export_excel: true,
    export_pdf: false,
    api_access: 'none',
    white_label: false,
    custom_domain: false,
    priority_support: false,
    dedicated_account_manager: false,
    sla_guarantee: 'none',
  },

  // ==========================================
  // PROFESSIONAL - €249/mes
  // ==========================================
  professional: {
    // Usuarios y Organizaciones
    max_users: 25,
    max_organizations_owned: 3,
    max_organizations_joined: 10,
    
    // CRM
    max_leads_per_month: 5000,
    lead_scoring: true,
    pipeline_drag_drop: true,
    deal_velocity: true,
    pipeline_forecast: true,
    
    // OKRs
    max_okrs: -1, // Ilimitado
    okr_dependencies: true,
    okr_quarterly_view: true,
    okr_check_ins: true,
    okr_retrospectives: true,
    
    // Análisis IA
    max_ai_analyses_per_month: 8,
    
    // Análisis Competitivo ← NUEVO (Feature Killer)
    include_competitor_analysis: true,
    max_competitors: 10, // Hasta 10 competidores
    competitor_analysis_depth: 'advanced',
    competitor_analysis_frequency: 'daily',
    competitor_price_alerts: true,
    competitor_feature_tracking: true,
    
    // Herramientas IA
    max_ai_tools: -1, // Ilimitado
    custom_ai_prompts: true,
    
    // Tareas
    available_phases: [1, 2, 3, 4], // Todas las fases
    task_swaps_per_week: 10,
    collaborative_tasks: true,
    
    // Features Premium
    google_calendar_integration: true,
    export_csv: true,
    export_excel: true,
    export_pdf: true,
    api_access: 'read',
    white_label: false,
    custom_domain: false,
    priority_support: true,
    dedicated_account_manager: false,
    sla_guarantee: '99%',
  },

  // ==========================================
  // ENTERPRISE - €499/mes
  // ==========================================
  enterprise: {
    // Usuarios y Organizaciones
    max_users: -1, // Ilimitado
    max_organizations_owned: -1,
    max_organizations_joined: -1,
    
    // CRM
    max_leads_per_month: -1, // Ilimitado
    lead_scoring: true,
    pipeline_drag_drop: true,
    deal_velocity: true,
    pipeline_forecast: true,
    
    // OKRs
    max_okrs: -1,
    okr_dependencies: true,
    okr_quarterly_view: true,
    okr_check_ins: true,
    okr_retrospectives: true,
    
    // Análisis IA
    max_ai_analyses_per_month: -1, // Ilimitado
    
    // Análisis Competitivo ← NUEVO (Todo ilimitado)
    include_competitor_analysis: true,
    max_competitors: -1, // Ilimitado
    competitor_analysis_depth: 'premium',
    competitor_analysis_frequency: 'realtime',
    competitor_price_alerts: true,
    competitor_feature_tracking: true,
    
    // Herramientas IA
    max_ai_tools: -1,
    custom_ai_prompts: true,
    
    // Tareas
    available_phases: [1, 2, 3, 4],
    task_swaps_per_week: -1, // Ilimitado
    collaborative_tasks: true,
    
    // Features Premium
    google_calendar_integration: true,
    export_csv: true,
    export_excel: true,
    export_pdf: true,
    api_access: 'read-write',
    white_label: true,
    custom_domain: true,
    priority_support: true,
    dedicated_account_manager: true,
    sla_guarantee: '99.9%',
  },
};

// ==========================================
// FUNCIONES AUXILIARES
// ==========================================

export function getPlanLimits(plan: SubscriptionPlan): PlanLimits {
  return PLAN_LIMITS[plan] || PLAN_LIMITS.free;
}

export function hasPlanFeature(plan: SubscriptionPlan, feature: keyof PlanLimits): boolean {
  const limits = getPlanLimits(plan);
  const value = limits[feature];
  
  // Si es booleano, retornar directo
  if (typeof value === 'boolean') {
    return value;
  }
  
  // Si es número, verificar que no sea 0 o -1 significa ilimitado
  if (typeof value === 'number') {
    return value !== 0;
  }
  
  // Si es string, verificar que no sea 'none'
  if (typeof value === 'string') {
    return value !== 'none';
  }
  
  return false;
}

export function isLimitReached(
  currentCount: number,
  plan: SubscriptionPlan,
  limitKey: keyof PlanLimits
): boolean {
  const limits = getPlanLimits(plan);
  const limit = limits[limitKey];
  
  // Si no es número, no aplica límite
  if (typeof limit !== 'number') {
    return false;
  }
  
  // -1 significa ilimitado
  if (limit === -1) {
    return false;
  }
  
  return currentCount >= limit;
}

export function getRecommendedUpgrade(
  plan: SubscriptionPlan,
  reason: 'users' | 'leads' | 'competitors' | 'ai_analyses' | 'features'
): SubscriptionPlan | null {
  const upgradeMap: Record<string, Record<SubscriptionPlan, SubscriptionPlan | null>> = {
    users: {
      free: 'starter',
      trial: 'starter',
      starter: 'professional',
      professional: 'enterprise',
      enterprise: null,
    },
    leads: {
      free: 'starter',
      trial: 'starter',
      starter: 'professional',
      professional: 'enterprise',
      enterprise: null,
    },
    competitors: {
      free: 'trial', // Probar en trial primero
      trial: 'starter',
      starter: 'professional', // Salto importante aquí
      professional: 'enterprise',
      enterprise: null,
    },
    ai_analyses: {
      free: 'starter',
      trial: 'starter',
      starter: 'professional',
      professional: 'enterprise',
      enterprise: null,
    },
    features: {
      free: 'starter',
      trial: 'starter',
      starter: 'professional',
      professional: 'enterprise',
      enterprise: null,
    },
  };

  return upgradeMap[reason]?.[plan] || null;
}

// ==========================================
// MENSAJES PARA UPGRADE MODAL
// ==========================================

export function getUpgradeMessage(
  plan: SubscriptionPlan,
  reason: 'users' | 'leads' | 'competitors' | 'ai_analyses' | 'okrs' | 'phase' | 'feature'
): string {
  const messages: Record<string, string> = {
    users: `Has alcanzado el límite de ${PLAN_LIMITS[plan].max_users} usuarios en el plan ${plan}. Upgrade para añadir más miembros a tu equipo.`,
    leads: `Has alcanzado el límite de ${PLAN_LIMITS[plan].max_leads_per_month} leads/mes en el plan ${plan}. Upgrade para gestionar más leads.`,
    competitors: plan === 'free' 
      ? `El análisis competitivo no está disponible en el plan free. Inicia un trial gratuito de 14 días para probarlo.`
      : `Has alcanzado el límite de ${PLAN_LIMITS[plan].max_competitors} competidores en el plan ${plan}. Upgrade para analizar más competencia.`,
    ai_analyses: `Has alcanzado el límite de ${PLAN_LIMITS[plan].max_ai_analyses_per_month} análisis con IA este mes. Upgrade para más análisis.`,
    okrs: `Has alcanzado el límite de ${PLAN_LIMITS[plan].max_okrs} OKRs en el plan ${plan}. Upgrade para más objetivos.`,
    phase: 'Esta fase no está disponible en tu plan actual. Upgrade para acceder a todas las fases.',
    feature: 'Esta funcionalidad no está disponible en tu plan actual. Upgrade para desbloquearla.',
  };

  return messages[reason] || 'Upgrade para desbloquear esta funcionalidad.';
}

export default PLAN_LIMITS;
