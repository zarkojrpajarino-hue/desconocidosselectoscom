/**
 * EDGE FUNCTION: ANÁLISIS CON IA (ACTUALIZADO CON COMPETIDORES)
 * 
 * Analiza datos de la organización incluyendo:
 * - Salud Financiera
 * - Rendimiento del Equipo
 * - Análisis de Competidores ← NUEVO
 * - Feedback Honesto
 * - Action Items
 * - Proyecciones de Crecimiento
 * 
 * Path: supabase/functions/analyze-project-data-v3/index.ts
 */

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// ============================================
// LÍMITES DE ANÁLISIS POR PLAN
// ============================================

const ANALYSIS_LIMITS = {
  free: {
    max_analyses_per_month: 1,
    include_competitor_analysis: false,
    max_competitors_analyzed: 0,
    analysis_depth: 'basic'
  },
  trial: {
    max_analyses_per_month: 2,
    include_competitor_analysis: true,
    max_competitors_analyzed: 1,
    analysis_depth: 'standard'
  },
  starter: {
    max_analyses_per_month: 4,
    include_competitor_analysis: true,
    max_competitors_analyzed: 3,
    analysis_depth: 'standard'
  },
  professional: {
    max_analyses_per_month: 8,
    include_competitor_analysis: true,
    max_competitors_analyzed: 10,
    analysis_depth: 'advanced'
  },
  enterprise: {
    max_analyses_per_month: -1, // ilimitado
    include_competitor_analysis: true,
    max_competitors_analyzed: -1, // ilimitado
    analysis_depth: 'premium'
  }
};

// ============================================
// HANDLER PRINCIPAL
// ============================================

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    // Obtener usuario
    const {
      data: { user },
    } = await supabaseClient.auth.getUser();

    if (!user) {
      throw new Error('No autorizado');
    }

    // Obtener organización del usuario
    const { data: userRole } = await supabaseClient
      .from('user_roles')
      .select('organization_id, organizations(plan)')
      .eq('user_id', user.id)
      .single();

    if (!userRole) {
      throw new Error('No se encontró organización');
    }

    const organizationId = userRole.organization_id;
    const plan = userRole.organizations.plan;
    const limits = ANALYSIS_LIMITS[plan] || ANALYSIS_LIMITS.free;

    // Verificar límites de análisis
    const canAnalyze = await checkAnalysisLimits(
      supabaseClient,
      organizationId,
      plan,
      limits
    );

    if (!canAnalyze.allowed) {
      return new Response(
        JSON.stringify({
          error: 'Límite de análisis alcanzado',
          message: canAnalyze.message,
          current_usage: canAnalyze.current_usage,
          limit: canAnalyze.limit,
        }),
        {
          status: 403,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // 1. RECOPILAR DATOS
    console.log('Recopilando datos...');
    const data = await gatherOrganizationData(supabaseClient, organizationId, limits);

    // 2. ANALIZAR CON IA
    console.log('Analizando con IA...');
    const analysis = await analyzeWithAI(data, plan, limits);

    // 3. GUARDAR RESULTADO
    console.log('Guardando resultado...');
    const { data: savedAnalysis, error: saveError } = await supabaseClient
      .from('ai_analysis_results')
      .insert({
        organization_id: organizationId,
        user_id: user.id,
        financial_health: analysis.financial_health,
        team_performance: analysis.team_performance,
        competitive_analysis: analysis.competitive_analysis, // ← NUEVO
        honest_feedback: analysis.honest_feedback,
        action_items: analysis.action_items,
        growth_projections: analysis.growth_projections,
        analysis_metadata: {
          plan: plan,
          competitors_analyzed: data.competitors?.length || 0,
          data_sources_used: Object.keys(data),
          analysis_depth: limits.analysis_depth
        }
      })
      .select()
      .single();

    if (saveError) throw saveError;

    return new Response(JSON.stringify(savedAnalysis), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error en análisis:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

// ============================================
// VERIFICAR LÍMITES DE ANÁLISIS
// ============================================

async function checkAnalysisLimits(
  supabase: any,
  organizationId: string,
  plan: string,
  limits: any
) {
  // Si es ilimitado
  if (limits.max_analyses_per_month === -1) {
    return { allowed: true };
  }

  // Contar análisis del mes actual
  const startOfMonth = new Date();
  startOfMonth.setDate(1);
  startOfMonth.setHours(0, 0, 0, 0);

  const { count } = await supabase
    .from('ai_analysis_results')
    .select('*', { count: 'exact', head: true })
    .eq('organization_id', organizationId)
    .gte('analyzed_at', startOfMonth.toISOString());

  const allowed = count < limits.max_analyses_per_month;

  return {
    allowed,
    current_usage: count,
    limit: limits.max_analyses_per_month,
    message: allowed
      ? 'Análisis permitido'
      : `Has alcanzado el límite de ${limits.max_analyses_per_month} análisis por mes en el plan ${plan}. Upgrade para más análisis.`,
  };
}

// ============================================
// RECOPILAR DATOS DE LA ORGANIZACIÓN
// ============================================

async function gatherOrganizationData(
  supabase: any,
  organizationId: string,
  limits: any
) {
  const data: any = {};

  // Fecha de hace 90 días
  const ninetyDaysAgo = new Date();
  ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);

  // 1. DATOS FINANCIEROS
  const { data: financialData } = await supabase
    .from('financial_transactions')
    .select('*')
    .eq('organization_id', organizationId)
    .gte('date', ninetyDaysAgo.toISOString())
    .order('date', { ascending: false });

  data.financial = financialData || [];

  // 2. MÉTRICAS
  const { data: metricsData } = await supabase
    .from('business_metrics_history')
    .select('*')
    .eq('organization_id', organizationId)
    .gte('recorded_at', ninetyDaysAgo.toISOString())
    .order('recorded_at', { ascending: false });

  data.metrics = metricsData || [];

  // 3. TAREAS Y COMPLETACIONES
  const { data: tasksData } = await supabase
    .from('task_completions')
    .select(`
      *,
      task:tasks(title, phase, area),
      user:profiles(full_name)
    `)
    .eq('organization_id', organizationId)
    .gte('completed_at', ninetyDaysAgo.toISOString());

  data.tasks = tasksData || [];

  // 4. LEADS Y CRM
  const { data: leadsData } = await supabase
    .from('leads')
    .select('*')
    .eq('organization_id', organizationId);

  data.leads = leadsData || [];

  // 5. OKRs
  const { data: okrsData } = await supabase
    .from('okrs')
    .select(`
      *,
      key_results(*)
    `)
    .eq('organization_id', organizationId);

  data.okrs = okrsData || [];

  // 6. ONBOARDING
  const { data: onboardingData } = await supabase
    .from('onboarding_data')
    .select('*')
    .eq('organization_id', organizationId)
    .single();

  data.onboarding = onboardingData || null;

  // 7. COMPETIDORES (NUEVO) ← AQUÍ ESTÁ LA MAGIA
  if (limits.include_competitor_analysis) {
    const maxCompetitors = limits.max_competitors_analyzed === -1
      ? 999
      : limits.max_competitors_analyzed;

    const { data: competitorsData } = await supabase
      .from('competitors')
      .select('*')
      .eq('organization_id', organizationId)
      .limit(maxCompetitors);

    data.competitors = competitorsData || [];

    // Obtener análisis recientes de competidores
    if (data.competitors.length > 0) {
      const competitorIds = data.competitors.map((c: any) => c.id);
      
      const { data: analysesData } = await supabase
        .from('competitor_analyses')
        .select('*')
        .in('competitor_id', competitorIds)
        .order('analyzed_at', { ascending: false })
        .limit(10);

      data.competitor_analyses = analysesData || [];
    }
  }

  return data;
}

// ============================================
// ANALIZAR CON IA
// ============================================

async function analyzeWithAI(data: any, plan: string, limits: any) {
  const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
  
  if (!LOVABLE_API_KEY) {
    throw new Error('LOVABLE_API_KEY no configurada');
  }

  // Construir prompt según profundidad
  const systemPrompt = getSystemPrompt(limits.analysis_depth);
  const userPrompt = buildAnalysisPrompt(data, plan, limits);

  // Llamar a Lovable AI Gateway
  const response = await fetch('https://api.lovable.app/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${LOVABLE_API_KEY}`,
    },
    body: JSON.stringify({
      model: 'gemini-2.0-flash-exp',
      messages: [
        {
          role: 'system',
          content: systemPrompt,
        },
        {
          role: 'user',
          content: userPrompt,
        },
      ],
      temperature: 0.7,
      max_tokens: 4000,
    }),
  });

  if (!response.ok) {
    throw new Error(`Error en IA: ${response.statusText}`);
  }

  const result = await response.json();
  const analysisText = result.choices[0].message.content;

  // Parsear respuesta JSON
  const analysis = JSON.parse(analysisText);

  return analysis;
}

// ============================================
// SYSTEM PROMPT SEGÚN PROFUNDIDAD
// ============================================

function getSystemPrompt(depth: string): string {
  const basePrompt = `Eres un analista de negocios experto con 20 años de experiencia. 
Analizas datos de empresas y proporcionas insights accionables.

Tu análisis debe ser HONESTO, DIRECTO y ÚTIL. No endulces las cosas.
Si ves problemas, dílos claramente. Si ves oportunidades, destácalas.`;

  const depthAdditions = {
    basic: `
Proporciona un análisis básico y conciso.
Enfócate en los 3 puntos más importantes.`,
    
    standard: `
Proporciona un análisis completo pero conciso.
Incluye detalles específicos y recomendaciones claras.`,
    
    advanced: `
Proporciona un análisis profundo y detallado.
Incluye comparaciones con benchmarks de la industria.
Da recomendaciones específicas con pasos de acción.`,
    
    premium: `
Proporciona un análisis exhaustivo de nivel C-level.
Incluye proyecciones financieras, análisis de riesgos, y estrategias de crecimiento.
Compara con competidores específicos y benchmarks de industria.
Recomendaciones deben estar priorizadas por ROI y facilidad de implementación.`
  };

  return basePrompt + '\n\n' + depthAdditions[depth];
}

// ============================================
// BUILD PROMPT DE ANÁLISIS
// ============================================

function buildAnalysisPrompt(data: any, plan: string, limits: any): string {
  let prompt = `Analiza los siguientes datos de la empresa y responde SOLO con un JSON válido con esta estructura exacta:

{
  "financial_health": {
    "score": number (0-100),
    "status": "healthy" | "warning" | "critical",
    "key_metrics": {
      "burn_rate": number,
      "runway": number,
      "cash_flow": number,
      "revenue_trend": "up" | "down" | "stable"
    },
    "alerts": string[],
    "recommendations": string[]
  },
  "team_performance": {
    "productivity_score": number (0-100),
    "completion_rate": number (0-100),
    "completed_tasks": number,
    "top_performers": [{"name": string, "score": number}],
    "areas_of_improvement": string[],
    "team_health": "excellent" | "good" | "needs_attention" | "critical"
  },`;

  // AÑADIR ANÁLISIS DE COMPETIDORES SI ESTÁ HABILITADO
  if (limits.include_competitor_analysis && data.competitors?.length > 0) {
    prompt += `
  "competitive_analysis": {
    "market_position": "leader" | "challenger" | "follower" | "nicher",
    "competitive_strength": number (0-100),
    "competitors_analyzed": number,
    "key_insights": [
      {
        "competitor": string,
        "insight": string,
        "threat_level": "high" | "medium" | "low",
        "opportunity": string
      }
    ],
    "pricing_comparison": {
      "your_position": "premium" | "competitive" | "budget",
      "price_advantage": number (porcentaje vs promedio),
      "recommendation": string
    },
    "feature_gaps": [
      {
        "feature": string,
        "competitors_with_it": string[],
        "priority": "high" | "medium" | "low",
        "estimated_impact": string
      }
    ],
    "market_trends": string[],
    "strategic_recommendations": string[],
    "threat_assessment": {
      "immediate_threats": string[],
      "emerging_threats": string[],
      "mitigation_strategies": string[]
    }
  },`;
  }

  prompt += `
  "honest_feedback": string (2-3 párrafos directos y honestos),
  "action_items": [
    {
      "title": string,
      "description": string,
      "priority": "critical" | "high" | "medium" | "low",
      "deadline": string (formato "YYYY-MM-DD"),
      "estimated_impact": "high" | "medium" | "low",
      "complexity": "easy" | "medium" | "hard"
    }
  ],
  "growth_projections": {
    "conservative": {"revenue_12m": number, "customers_12m": number},
    "realistic": {"revenue_12m": number, "customers_12m": number},
    "optimistic": {"revenue_12m": number, "customers_12m": number}
  }
}

DATOS DE LA EMPRESA:

Plan actual: ${plan}

`;

  // 1. DATOS FINANCIEROS
  if (data.financial && data.financial.length > 0) {
    const revenues = data.financial.filter((t: any) => t.type === 'revenue');
    const expenses = data.financial.filter((t: any) => t.type === 'expense');
    
    const totalRevenue = revenues.reduce((sum: number, t: any) => sum + t.amount, 0);
    const totalExpenses = expenses.reduce((sum: number, t: any) => sum + t.amount, 0);
    
    prompt += `
FINANCIERO (últimos 90 días):
- Total ingresos: €${totalRevenue.toLocaleString()}
- Total gastos: €${totalExpenses.toLocaleString()}
- Margen: €${(totalRevenue - totalExpenses).toLocaleString()}
- Número de transacciones: ${data.financial.length}
`;
  }

  // 2. MÉTRICAS
  if (data.metrics && data.metrics.length > 0) {
    prompt += `\nMÉTRICAS CLAVE (últimos registros):
`;
    const latestMetrics = data.metrics.slice(0, 10);
    latestMetrics.forEach((m: any) => {
      prompt += `- ${m.metric_name}: ${m.value} ${m.unit || ''}\n`;
    });
  }

  // 3. TAREAS
  if (data.tasks && data.tasks.length > 0) {
    const totalTasks = data.tasks.length;
    const byUser = data.tasks.reduce((acc: any, t: any) => {
      const userName = t.user?.full_name || 'Unknown';
      acc[userName] = (acc[userName] || 0) + 1;
      return acc;
    }, {});

    prompt += `\nRENDIMIENTO EQUIPO (últimos 90 días):
- Total tareas completadas: ${totalTasks}
- Por usuario: ${JSON.stringify(byUser, null, 2)}
`;
  }

  // 4. LEADS
  if (data.leads && data.leads.length > 0) {
    const hotLeads = data.leads.filter((l: any) => l.lead_type === 'hot').length;
    const totalValue = data.leads.reduce((sum: number, l: any) => sum + (l.estimated_value || 0), 0);

    prompt += `\nCRM:
- Total leads: ${data.leads.length}
- Hot leads: ${hotLeads}
- Valor pipeline: €${totalValue.toLocaleString()}
`;
  }

  // 5. OKRs
  if (data.okrs && data.okrs.length > 0) {
    const avgProgress = data.okrs.reduce((sum: number, o: any) => sum + (o.progress || 0), 0) / data.okrs.length;

    prompt += `\nOKRs:
- Total objetivos: ${data.okrs.length}
- Progreso promedio: ${avgProgress.toFixed(1)}%
`;
  }

  // 6. ONBOARDING
  if (data.onboarding) {
    prompt += `\nCONTEXTO NEGOCIO:
- Industria: ${data.onboarding.industry || 'N/A'}
- Tamaño empresa: ${data.onboarding.company_size || 'N/A'}
- Año fundación: ${data.onboarding.founding_year || 'N/A'}
- Modelo negocio: ${data.onboarding.business_model || 'N/A'}
- Meta revenue 12m: €${data.onboarding.target_revenue_12_months?.toLocaleString() || 'N/A'}
`;
  }

  // 7. COMPETIDORES (NUEVO) ← LA PARTE IMPORTANTE
  if (limits.include_competitor_analysis && data.competitors?.length > 0) {
    prompt += `\n\n=== ANÁLISIS COMPETITIVO ===

COMPETIDORES A ANALIZAR (${data.competitors.length}):
`;

    data.competitors.forEach((comp: any, index: number) => {
      prompt += `\n${index + 1}. ${comp.name}
   - Website: ${comp.website || 'N/A'}
   - Industria: ${comp.industry || 'N/A'}
   - Tamaño: ${comp.company_size || 'N/A'}
   - Pricing: €${comp.min_price || 0} - €${comp.max_price || 0}
   - Features: ${comp.features?.length || 0}
`;
      
      // Si hay features, listarlas
      if (comp.features && comp.features.length > 0) {
        prompt += `   - Features específicas: ${comp.features.slice(0, 5).join(', ')}${comp.features.length > 5 ? '...' : ''}\n`;
      }

      // Si hay datos de análisis previos
      if (comp.analysis_data) {
        prompt += `   - Última actualización: ${comp.last_analyzed_at || 'N/A'}\n`;
      }
    });

    prompt += `\n
INSTRUCCIONES ESPECÍFICAS PARA ANÁLISIS COMPETITIVO:

1. **Market Position**: Determina si la empresa es líder, retadora, seguidora o nicho basándote en:
   - Comparación de precios vs competidores
   - Número y calidad de features
   - Tamaño relativo de la empresa

2. **Key Insights**: Para CADA competidor, identifica:
   - ¿Qué hace mejor que nosotros?
   - ¿Qué amenaza representa?
   - ¿Qué oportunidad nos da su debilidad?

3. **Pricing Comparison**: Analiza si estamos:
   - Premium (más caros que la media)
   - Competitivos (en la media)
   - Budget (más baratos)
   Y si esto es ventaja o desventaja.

4. **Feature Gaps**: Identifica features que competidores tienen y nosotros NO.
   Prioriza por impacto en conversión y dificultad de implementación.

5. **Strategic Recommendations**: 3-5 acciones concretas para:
   - Defendernos de amenazas
   - Aprovechar oportunidades
   - Diferenciarnos más

IMPORTANTE: Sé específico, usa números, y da recomendaciones ACCIONABLES.
`;
  } else if (limits.include_competitor_analysis && data.competitors?.length === 0) {
    prompt += `\n\n=== NO HAY COMPETIDORES REGISTRADOS ===

La empresa no ha añadido competidores aún. En el análisis, incluye:
- Una recomendación URGENTE de añadir al menos 3 competidores principales
- Explica el valor de trackear competencia
- Sugiere cómo identificarlos (búsqueda Google, directorios, etc.)
`;
  }

  prompt += `\n\nRESPONDE SOLO CON EL JSON. NO añadas texto antes o después.`;

  return prompt;
}
