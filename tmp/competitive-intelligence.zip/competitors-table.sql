-- ============================================
-- TABLA DE COMPETIDORES
-- ============================================

CREATE TABLE IF NOT EXISTS competitors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  
  -- Información básica
  name TEXT NOT NULL,
  website TEXT,
  logo_url TEXT,
  description TEXT,
  
  -- Datos de negocio
  industry TEXT,
  founded_year INTEGER,
  company_size TEXT, -- 'startup', 'small', 'medium', 'large', 'enterprise'
  headquarters TEXT,
  
  -- Pricing
  pricing_model TEXT, -- 'freemium', 'subscription', 'one-time', 'custom'
  min_price DECIMAL(10,2),
  max_price DECIMAL(10,2),
  currency TEXT DEFAULT 'EUR',
  
  -- Features (array de texto)
  features JSONB DEFAULT '[]'::jsonb,
  
  -- Social Media
  linkedin_url TEXT,
  twitter_url TEXT,
  instagram_url TEXT,
  facebook_url TEXT,
  
  -- Métricas estimadas
  estimated_revenue DECIMAL(15,2),
  estimated_employees INTEGER,
  market_share DECIMAL(5,2), -- Porcentaje
  
  -- Análisis automático
  last_analyzed_at TIMESTAMPTZ,
  analysis_data JSONB, -- Datos del último análisis
  
  -- Alertas
  price_change_detected BOOLEAN DEFAULT false,
  last_price_change_at TIMESTAMPTZ,
  
  -- Metadata
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  created_by UUID REFERENCES auth.users(id)
);

-- Índices
CREATE INDEX idx_competitors_org_id ON competitors(organization_id);
CREATE INDEX idx_competitors_last_analyzed ON competitors(last_analyzed_at);
CREATE INDEX idx_competitors_website ON competitors(website);

-- RLS
ALTER TABLE competitors ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view competitors from their organization"
  ON competitors FOR SELECT
  USING (
    organization_id IN (
      SELECT organization_id 
      FROM user_roles 
      WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage competitors"
  ON competitors FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_id = auth.uid()
        AND organization_id = competitors.organization_id
        AND role = 'admin'
    )
  );

-- Trigger para updated_at
CREATE OR REPLACE FUNCTION update_competitors_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER competitors_updated_at
  BEFORE UPDATE ON competitors
  FOR EACH ROW
  EXECUTE FUNCTION update_competitors_updated_at();

-- ============================================
-- TABLA DE ANÁLISIS DE COMPETIDORES (HISTÓRICO)
-- ============================================

CREATE TABLE IF NOT EXISTS competitor_analyses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  competitor_id UUID NOT NULL REFERENCES competitors(id) ON DELETE CASCADE,
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  
  -- Datos del análisis
  analysis_type TEXT NOT NULL, -- 'pricing', 'features', 'social', 'full'
  analysis_data JSONB NOT NULL,
  
  -- Cambios detectados
  changes_detected JSONB DEFAULT '[]'::jsonb,
  
  -- Metadata
  analyzed_at TIMESTAMPTZ DEFAULT now(),
  analyzed_by UUID REFERENCES auth.users(id)
);

-- Índices
CREATE INDEX idx_competitor_analyses_competitor ON competitor_analyses(competitor_id);
CREATE INDEX idx_competitor_analyses_org ON competitor_analyses(organization_id);
CREATE INDEX idx_competitor_analyses_date ON competitor_analyses(analyzed_at);

-- RLS
ALTER TABLE competitor_analyses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view competitor analyses from their org"
  ON competitor_analyses FOR SELECT
  USING (
    organization_id IN (
      SELECT organization_id 
      FROM user_roles 
      WHERE user_id = auth.uid()
    )
  );

-- ============================================
-- FUNCIONES AUXILIARES
-- ============================================

-- Función para obtener count de competidores
CREATE OR REPLACE FUNCTION get_competitor_count(org_id UUID)
RETURNS INTEGER AS $$
BEGIN
  RETURN (
    SELECT COUNT(*)
    FROM competitors
    WHERE organization_id = org_id
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Función para verificar si puede añadir más competidores
CREATE OR REPLACE FUNCTION can_add_competitor(org_id UUID)
RETURNS JSONB AS $$
DECLARE
  current_count INTEGER;
  org_plan TEXT;
  max_competitors INTEGER;
BEGIN
  -- Obtener plan
  SELECT plan INTO org_plan
  FROM organizations
  WHERE id = org_id;
  
  -- Obtener count actual
  current_count := get_competitor_count(org_id);
  
  -- Determinar límite según plan
  max_competitors := CASE org_plan
    WHEN 'free' THEN 1
    WHEN 'trial' THEN 1
    WHEN 'starter' THEN 3
    WHEN 'professional' THEN 10
    WHEN 'enterprise' THEN -1 -- ilimitado
    ELSE 1
  END;
  
  -- Retornar resultado
  RETURN jsonb_build_object(
    'allowed', (max_competitors = -1 OR current_count < max_competitors),
    'current_count', current_count,
    'max_competitors', max_competitors,
    'plan', org_plan
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- DATOS DE EJEMPLO (OPCIONAL)
-- ============================================

-- Descomentar para insertar competidores de ejemplo
/*
INSERT INTO competitors (organization_id, name, website, industry, pricing_model, min_price, max_price, features)
SELECT 
  o.id,
  'Competitor Example',
  'https://competitor.com',
  'SaaS',
  'subscription',
  99.00,
  499.00,
  '["Feature 1", "Feature 2", "Feature 3"]'::jsonb
FROM organizations o
LIMIT 1;
*/
