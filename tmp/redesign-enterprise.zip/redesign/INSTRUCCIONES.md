# 🎨 REDISEÑO COMPLETO - INSTRUCCIONES DE IMPLEMENTACIÓN

## Resumen del Sistema de Diseño

Este paquete contiene un rediseño completo de la aplicación con:
- **Nueva paleta de colores** - Azul profesional con acentos violeta
- **Nueva tipografía** - Plus Jakarta Sans + Inter
- **Layout con Sidebar** - Navegación fija lateral
- **Componentes UI mejorados** - Cards, Stats, Headers
- **Dashboard rediseñado** - Más visual e intuitivo
- **Animaciones sutiles** - Transiciones profesionales

---

## 📦 CONTENIDO DEL PAQUETE

```
redesign/
├── docs/
│   └── BRAND_GUIDELINES.md      # Guía completa del sistema de diseño
├── src/
│   ├── styles/
│   │   └── index.css            # REEMPLAZA tu src/index.css
│   ├── components/
│   │   ├── layout/
│   │   │   ├── AppLayout.tsx    # Layout principal con sidebar
│   │   │   ├── Sidebar.tsx      # Navegación lateral
│   │   │   └── Header.tsx       # Header superior
│   │   └── ui-custom/
│   │       ├── StatCard.tsx     # Cards de estadísticas
│   │       └── PageHeader.tsx   # Headers de página
│   └── pages/
│       ├── Home.tsx             # Home rediseñado
│       └── dashboard/
│           └── DashboardHome.tsx # Dashboard rediseñado
└── INSTRUCCIONES.md             # Este archivo
```

---

## 🔧 PASO 1: Instalar Fuentes

Añade estas fuentes a tu `index.html` en el `<head>`:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
```

O alternativamente, ya está incluido en el nuevo `index.css` con `@import`.

---

## 🔧 PASO 2: Reemplazar index.css

**IMPORTANTE**: Haz backup de tu `src/index.css` actual primero.

Reemplaza completamente `src/index.css` con el archivo `src/styles/index.css` de este paquete.

---

## 🔧 PASO 3: Añadir Componentes de Layout

### 3.1 Crear carpeta de layout
```bash
mkdir -p src/components/layout
```

### 3.2 Copiar archivos
Copia estos archivos a `src/components/layout/`:
- `Sidebar.tsx`
- `Header.tsx`
- `AppLayout.tsx`

### 3.3 Crear index de exports
Crea `src/components/layout/index.ts`:
```typescript
export { Sidebar } from './Sidebar';
export { Header } from './Header';
export { AppLayout } from './AppLayout';
```

---

## 🔧 PASO 4: Añadir Componentes UI Custom

### 4.1 Crear carpeta
```bash
mkdir -p src/components/ui-custom
```

### 4.2 Copiar archivos
Copia estos archivos a `src/components/ui-custom/`:
- `StatCard.tsx`
- `PageHeader.tsx`

### 4.3 Crear index de exports
Crea `src/components/ui-custom/index.ts`:
```typescript
export { StatCard, StatsGrid } from './StatCard';
export { PageHeader, CreateButton, ExportButton, SettingsButton } from './PageHeader';
```

---

## 🔧 PASO 5: Actualizar el Routing (App.tsx)

Modifica tu `App.tsx` para usar el nuevo `AppLayout`:

```typescript
import { AppLayout } from '@/components/layout';

// En tus rutas protegidas, envuelve con AppLayout:
<Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
  <Route path="/dashboard/*" element={<Dashboard />} />
  <Route path="/home" element={<Home />} />
  <Route path="/metrics/*" element={<MetricsHub />} />
  {/* ... resto de rutas protegidas */}
</Route>
```

### Ejemplo completo de estructura de rutas:

```typescript
<Routes>
  {/* Rutas públicas (sin layout) */}
  <Route path="/login" element={<Login />} />
  <Route path="/signup" element={<Signup />} />
  <Route path="/landing" element={<Landing />} />
  
  {/* Rutas protegidas con AppLayout */}
  <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
    <Route path="/" element={<Navigate to="/home" replace />} />
    <Route path="/home" element={<Home />} />
    <Route path="/dashboard/*" element={<Dashboard />} />
    <Route path="/metrics/*" element={<MetricsHub />} />
    <Route path="/ai-analysis" element={<AIAnalysis />} />
    <Route path="/herramientas-hub" element={<HerramientasHub />} />
    <Route path="/gamification" element={<Gamification />} />
    <Route path="/profile" element={<Profile />} />
    <Route path="/alerts" element={<AlertsPage />} />
    {/* ... etc */}
  </Route>
</Routes>
```

---

## 🔧 PASO 6: Reemplazar Páginas

### Home.tsx
Reemplaza `src/pages/Home.tsx` con el archivo del paquete.

### DashboardHome.tsx
Reemplaza `src/pages/dashboard/DashboardHome.tsx` con el archivo del paquete.

---

## 🔧 PASO 7: Actualizar tailwind.config.ts

Añade estas extensiones a tu `tailwind.config.ts`:

```typescript
// En theme.extend:
fontFamily: {
  sans: ['Inter', 'system-ui', 'sans-serif'],
  display: ['Plus Jakarta Sans', 'system-ui', 'sans-serif'],
  mono: ['JetBrains Mono', 'monospace'],
},
colors: {
  // ... tus colores existentes
  info: {
    DEFAULT: "hsl(var(--info))",
    foreground: "hsl(var(--info-foreground))",
  },
  sidebar: {
    DEFAULT: "hsl(var(--sidebar-bg))",
    foreground: "hsl(var(--sidebar-foreground))",
    muted: "hsl(var(--sidebar-muted))",
    accent: "hsl(var(--sidebar-accent))",
    border: "hsl(var(--sidebar-border))",
  },
},
```

---

## ✅ CHECKLIST DE VERIFICACIÓN

Después de implementar, verifica:

- [ ] Fuentes cargando correctamente (Plus Jakarta Sans en títulos)
- [ ] Sidebar visible en desktop, oculto en móvil
- [ ] Header con breadcrumbs funcionando
- [ ] Animaciones de entrada en páginas
- [ ] Dark mode funcionando
- [ ] Cards con hover effects
- [ ] Colores aplicados correctamente

---

## 🎨 PERSONALIZACIÓN

### Cambiar colores principales

En `index.css`, modifica las variables CSS:

```css
:root {
  /* Primary - Cambia el azul por tu color */
  --primary: 217 91% 60%;  /* HSL format */
  
  /* Accent - Color secundario/destacado */
  --accent: 258 90% 66%;
}
```

### Cambiar fuentes

En `index.css`, modifica el @import y las reglas de font-family:

```css
@import url('https://fonts.googleapis.com/css2?family=TU_FUENTE...');

body {
  font-family: 'Tu Fuente', system-ui, sans-serif;
}
```

---

## 📱 RESPONSIVE

El sistema está diseñado para ser responsive:

- **Mobile (<1024px)**: Sidebar oculto, hamburger menu
- **Desktop (≥1024px)**: Sidebar fijo visible

La sidebar tiene 256px (w-64) de ancho. El contenido principal tiene `lg:pl-64` para compensar.

---

## 🔄 MIGRACIÓN GRADUAL

Si prefieres migrar gradualmente:

1. **Fase 1**: Solo CSS y colores (index.css)
2. **Fase 2**: Añadir Sidebar y Header
3. **Fase 3**: Actualizar Dashboard
4. **Fase 4**: Actualizar resto de páginas

---

## 🆘 PROBLEMAS COMUNES

### Sidebar no aparece
- Verifica que `AppLayout` esté envolviendo las rutas
- Verifica que el CSS de `.sidebar` esté cargado

### Fuentes no cargan
- Verifica conexión a internet
- Verifica que el @import esté al inicio de index.css

### Colores no cambian
- Limpia caché del navegador
- Verifica que el nuevo index.css esté importado

### Layout roto en móvil
- Verifica media queries en CSS
- Verifica clases `lg:` de Tailwind

---

## 📊 RESULTADO ESPERADO

Después de implementar tendrás:

| Aspecto | Antes | Después |
|---------|-------|---------|
| Navegación | Tabs en cada página | Sidebar fijo global |
| Tipografía | Sistema genérico | Plus Jakarta Sans + Inter |
| Colores | Púrpura básico | Azul profesional con gradientes |
| Cards | Básicas | Con hover, gradientes, sombras |
| Animaciones | Ninguna | Fade, slide, scale |
| Dashboard | Básico | Visual con stats, progress, team |
| Responsive | Parcial | Completo con sidebar móvil |

---

¡Tu app ahora tendrá un aspecto enterprise profesional y distintivo! 🚀
