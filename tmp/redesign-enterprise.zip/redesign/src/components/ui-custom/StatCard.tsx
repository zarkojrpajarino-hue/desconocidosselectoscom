import { ReactNode } from 'react';
import { cn } from '@/lib/utils';
import { TrendingUp, TrendingDown, Minus, ArrowRight } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: ReactNode;
  trend?: {
    value: number;
    label?: string;
    isPositive?: boolean;
  };
  variant?: 'default' | 'primary' | 'success' | 'warning' | 'destructive';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  onClick?: () => void;
}

const variantStyles = {
  default: {
    card: 'bg-card border-border',
    icon: 'bg-muted text-muted-foreground',
    value: 'text-foreground',
  },
  primary: {
    card: 'bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20',
    icon: 'bg-primary text-primary-foreground',
    value: 'text-primary',
  },
  success: {
    card: 'bg-gradient-to-br from-success/10 to-success/5 border-success/20',
    icon: 'bg-success text-success-foreground',
    value: 'text-success',
  },
  warning: {
    card: 'bg-gradient-to-br from-warning/10 to-warning/5 border-warning/20',
    icon: 'bg-warning text-warning-foreground',
    value: 'text-warning',
  },
  destructive: {
    card: 'bg-gradient-to-br from-destructive/10 to-destructive/5 border-destructive/20',
    icon: 'bg-destructive text-destructive-foreground',
    value: 'text-destructive',
  },
};

const sizeStyles = {
  sm: {
    card: 'p-4',
    icon: 'w-8 h-8',
    iconInner: 'w-4 h-4',
    value: 'text-2xl',
    title: 'text-xs',
  },
  md: {
    card: 'p-5',
    icon: 'w-10 h-10',
    iconInner: 'w-5 h-5',
    value: 'text-3xl',
    title: 'text-sm',
  },
  lg: {
    card: 'p-6',
    icon: 'w-12 h-12',
    iconInner: 'w-6 h-6',
    value: 'text-4xl',
    title: 'text-base',
  },
};

export function StatCard({
  title,
  value,
  subtitle,
  icon,
  trend,
  variant = 'default',
  size = 'md',
  className,
  onClick,
}: StatCardProps) {
  const styles = variantStyles[variant];
  const sizes = sizeStyles[size];

  const TrendIcon = trend
    ? trend.value > 0
      ? TrendingUp
      : trend.value < 0
      ? TrendingDown
      : Minus
    : null;

  const trendColor = trend
    ? trend.isPositive !== undefined
      ? trend.isPositive
        ? 'text-success'
        : 'text-destructive'
      : trend.value > 0
      ? 'text-success'
      : trend.value < 0
      ? 'text-destructive'
      : 'text-muted-foreground'
    : '';

  return (
    <div
      className={cn(
        'rounded-xl border transition-all duration-200',
        sizes.card,
        styles.card,
        onClick && 'cursor-pointer hover:shadow-lg hover:-translate-y-0.5',
        className
      )}
      onClick={onClick}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <p className={cn('font-medium text-muted-foreground mb-1', sizes.title)}>
            {title}
          </p>
          <p className={cn('font-bold tracking-tight', sizes.value, styles.value)}>
            {value}
          </p>
          {subtitle && (
            <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>
          )}
          {trend && (
            <div className={cn('flex items-center gap-1.5 mt-2', trendColor)}>
              {TrendIcon && <TrendIcon className="w-4 h-4" />}
              <span className="text-sm font-medium">
                {trend.value > 0 ? '+' : ''}
                {trend.value}%
              </span>
              {trend.label && (
                <span className="text-xs text-muted-foreground">{trend.label}</span>
              )}
            </div>
          )}
        </div>
        {icon && (
          <div
            className={cn(
              'rounded-xl flex items-center justify-center flex-shrink-0',
              sizes.icon,
              styles.icon
            )}
          >
            <div className={sizes.iconInner}>{icon}</div>
          </div>
        )}
      </div>
      {onClick && (
        <div className="flex items-center gap-1 text-xs text-muted-foreground mt-4 pt-4 border-t border-border/50">
          <span>Ver detalles</span>
          <ArrowRight className="w-3 h-3" />
        </div>
      )}
    </div>
  );
}

// Grid de estadísticas
interface StatsGridProps {
  children: ReactNode;
  columns?: 2 | 3 | 4;
  className?: string;
}

export function StatsGrid({ children, columns = 4, className }: StatsGridProps) {
  const gridCols = {
    2: 'md:grid-cols-2',
    3: 'md:grid-cols-2 lg:grid-cols-3',
    4: 'sm:grid-cols-2 lg:grid-cols-4',
  };

  return (
    <div className={cn('grid gap-4', gridCols[columns], className)}>
      {children}
    </div>
  );
}

export default StatCard;
